/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { AppProvider, useApp } from "./components/AppContext";
import Navbar from "./components/Navbar";
import AuthModal from "./components/AuthModal";
import LookbookSection from "./components/LookbookSection";
import ProductsSection from "./components/ProductsSection";
import AIStylistSection from "./components/AIStylistSection";
import OrderTrackerSection from "./components/OrderTrackerSection";
import AdminPanel from "./components/AdminPanel";
import CartWishlist from "./components/CartWishlist";
import CheckoutModal from "./components/CheckoutModal";
import { Sparkles, ShoppingBag, Heart, Shield, CheckCircle2, AlertCircle, RefreshCw, KeyRound } from "lucide-react";

function MainLayout() {
  const { 
    currentUser, 
    successMsg, 
    errorMsg, 
    showAuthModal, 
    setShowAuthModal,
    loginUser
  } = useApp();

  const [activeTab, setActiveTab] = useState<'lookbook' | 'catalog' | 'stylist' | 'tracker' | 'admin'>('lookbook');
  const [cartOpen, setCartOpen] = useState(false);
  const [wishlistOpen, setWishlistOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [activePanel, setActivePanel] = useState<'cart' | 'wishlist'>('cart');

  // Multi-view navigation router
  const renderViewContent = () => {
    switch (activeTab) {
      case 'lookbook':
        return <LookbookSection />;
      case 'catalog':
        return <ProductsSection />;
      case 'stylist':
        return <AIStylistSection />;
      case 'tracker':
        return <OrderTrackerSection />;
      case 'admin':
        return <AdminPanel />;
      default:
        return <LookbookSection />;
    }
  };

  const handleOpenCart = () => {
    setActivePanel('cart');
    setCartOpen(true);
  };

  const handleOpenWishlist = () => {
    setActivePanel('wishlist');
    setCartOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#F9F8F6] dark:bg-[#0F0F0E] text-[#1A1A1A] dark:text-[#F5F4F0] flex flex-col justify-between font-sans selection:bg-[#C4A484]/30 selection:text-black overflow-x-hidden geometric-grid transition-colors duration-300">
      
      {/* Absolute Professional Academic Header Strip */}
      <header className="h-12 border-b border-[#1A1A1A] dark:border-[#F5F4F0]/15 flex items-center justify-between px-4 sm:px-8 bg-white dark:bg-[#121211] text-[#1A1A1A] dark:text-[#F5F4F0] z-10 w-full shrink-0 transition-colors">
        <div className="flex items-center space-x-4">
          <span className="text-[10px] font-bold tracking-[0.2em] uppercase opacity-40">Project Framework</span>
          <span className="text-[11px] font-mono tracking-wider text-neutral-700 dark:text-neutral-300 hidden sm:inline">25CS1201E / TERM-III 2025-26</span>
        </div>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2 whitespace-nowrap">
            <span className="text-[10px] uppercase tracking-tighter opacity-50 font-mono font-bold">Lead</span>
            <span className="text-[11px] font-medium italic text-neutral-800 dark:text-neutral-200">Kartheek Reddy • 2520090015</span>
          </div>
          <div className="w-px h-4 bg-[#1A1A1A]/10 dark:bg-[#F5F4F0]/15"></div>
          <div className="flex items-center space-x-2 whitespace-nowrap">
            <span className="text-[10px] uppercase tracking-tighter opacity-50 font-mono font-bold">Partner</span>
            <span className="text-[11px] font-medium italic text-neutral-800 dark:text-neutral-200">Chinmaya Apoorva • 2520030078</span>
          </div>
        </div>
      </header>

      {/* Dynamic Toast feedback container */}
      <div className="fixed top-28 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 max-w-md w-11/12 pointer-events-none">
        {successMsg && (
          <div className="bg-[#1A1A1A] text-white px-4 py-3 border border-[#1a1a1a] text-xs font-mono tracking-wider uppercase flex items-center gap-3 shadow-md pointer-events-auto">
            <CheckCircle2 className="w-4 h-4 text-[#C4A484] shrink-0" />
            <span className="font-semibold leading-none">{successMsg}</span>
          </div>
        )}
        {errorMsg && (
          <div className="bg-[#8B0000] text-white px-4 py-3 border border-[#8B0000] text-xs font-mono tracking-wider uppercase flex items-center gap-3 shadow-md pointer-events-auto">
            <AlertCircle className="w-4 h-4 text-red-200 shrink-0" />
            <span className="font-semibold leading-none">{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Main Structural Wrapper */}
      <div className="flex-1 flex flex-col">
        
        {/* Custom Header Navigation */}
        <Navbar
          activeTab={activeTab}
          onTabChange={(tab) => {
            setActiveTab(tab);
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
          onOpenCart={handleOpenCart}
          onOpenWishlist={handleOpenWishlist}
        />

        {/* View Section wrapper with entry animation fade */}
        <main className="flex-1 pb-16 pt-6">
          <div className="animate-fade-in">
            {renderViewContent()}
          </div>
        </main>
      </div>

      {/* Visual Footer Status Bar */}
      <footer className="h-14 sm:h-12 border-t border-[#1A1A1A] dark:border-[#F5F4F0]/15 flex flex-col sm:flex-row items-center justify-between px-6 sm:px-8 bg-white dark:bg-[#121211] text-[10px] font-bold tracking-widest uppercase py-2 sm:py-0 shrink-0 text-center gap-2 sm:gap-0 text-[#1A1A1A] dark:text-[#F5F4F0] transition-colors">
        <div className="flex flex-wrap space-x-4 sm:space-x-6 items-center justify-center">
          <div className="flex items-center space-x-2">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-stone-700 dark:text-stone-300">System Live</span>
          </div>
          <span className="opacity-30">|</span>
          <span className="text-stone-700 dark:text-stone-300 font-mono text-[9px]">DB: MemDB Sync Ready</span>
          <span className="opacity-30">|</span>
          <span className="text-stone-500 dark:text-stone-400 font-mono text-[9px]">Coutura Node v20.4</span>
        </div>
        <div className="flex space-x-6 items-center justify-center">
          <span className="opacity-60 text-stone-500 dark:text-stone-400">© 2026 Aura Coutura</span>
          <div className="flex space-x-1">
            <div className="w-6 h-6 border border-[#1A1A1A] dark:border-[#F5F4F0]/25 text-stone-700 dark:text-stone-300 flex items-center justify-center font-mono text-[9px] hover:bg-[#1A1A1A] hover:text-white dark:hover:bg-[#F5F4F0] dark:hover:text-black transition cursor-pointer">IG</div>
            <div className="w-6 h-6 border border-[#1A1A1A] dark:border-[#F5F4F0]/25 text-stone-700 dark:text-stone-300 flex items-center justify-center font-mono text-[9px] hover:bg-[#1A1A1A] hover:text-white dark:hover:bg-[#F5F4F0] dark:hover:text-black transition cursor-pointer">TW</div>
          </div>
        </div>
      </footer>

      {/* MODAL / DRAWER INTERFACES OVERLAY */}
      
      {/* Authenticate Account */}
      <AuthModal />

      {/* Cart & Wishlist Slid-Out Drawer */}
      <CartWishlist
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        activePanel={activePanel}
        setActivePanel={setActivePanel}
        onOpenCheckout={() => setCheckoutOpen(true)}
      />

      {/* Checkout Formulation sheet */}
      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
      />

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
