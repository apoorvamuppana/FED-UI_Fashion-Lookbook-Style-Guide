/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { useApp } from "./AppContext";
import { Collection, Product } from "../types";
import { ArrowRight, Sparkles, Image as ImageIcon, Heart } from "lucide-react";

export default function LookbookSection() {
  const { lookbooks, products, addToCart, toggleWishlist, isProductInWishlist } = useApp();
  const [selectedCollection, setSelectedCollection] = useState<Collection | null>(null);

  // Helper matching products in chosen collection
  const getCollectionProducts = (col: Collection): Product[] => {
    return products.filter(p => col.productIds.includes(p.id));
  };

  const handleAddAllToCart = (col: Collection) => {
    const matched = getCollectionProducts(col);
    for (const p of matched) {
      if (p.inventory > 0) {
        addToCart(p, "M", 1);
      }
    }
  };

  return (
    <div id="lookbook-module-view" className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Editorial Headline */}
      <div className="flex flex-col items-center text-center max-w-2xl mx-auto mb-16 border-b border-[#1A1A1A]/10 pb-12">
        <span className="font-serif text-sm tracking-widest text-[#C4A484] italic block mb-2">Curated Season Silhouettes</span>
        <h1 className="font-serif text-4xl sm:text-5xl text-[#1A1A1A] tracking-tighter leading-none font-black uppercase">
          Digital Lookbook
        </h1>
        <p className="font-mono text-[9px] tracking-[0.3em] text-[#1A1A1A]/60 uppercase font-bold mt-3">
          Interactive Design Collections • Volume III
        </p>
        <p className="font-sans text-xs text-stone-600 mt-5 leading-relaxed max-w-lg">
          Explore high-fashion capsules styled meticulously by pre-loaded student designers for 2026. Review matches, examine color coordinates, and directly save or clear combinations instantly.
        </p>
      </div>

      {/* Grid of Lookbook Campaigns with crisp geometric borders and hard sharp shadows */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        {lookbooks.map((col) => {
          const matchedCount = getCollectionProducts(col).length;
          return (
            <div
              key={col.id}
              className="group relative bg-white border border-[#1A1A1A] rounded-none overflow-hidden transition-all duration-300 flex flex-col shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] hover:shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] hover:-translate-x-1 hover:-translate-y-1"
            >
              {/* Cover Card */}
              <div className="aspect-[3/4] overflow-hidden relative border-b border-[#1A1A1A]">
                <img
                  src={col.coverUrl}
                  alt={col.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                
                {/* Floating dark premium overlay with editorial vibe */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A]/95 via-[#1A1A1A]/50 to-transparent flex flex-col justify-end p-6 text-white">
                  <span className="font-mono text-[9px] font-bold text-[#C4A484] uppercase tracking-widest block mb-1">
                    {col.season} Collection
                  </span>
                  <h3 className="font-serif text-2xl font-bold leading-none tracking-wide">
                    {col.name}
                  </h3>
                  <p className="font-sans text-xs text-stone-300 mt-2 line-clamp-2">
                    {col.description}
                  </p>
                  
                  {/* View collection metrics */}
                  <div className="mt-4 flex justify-between items-center pt-3 border-t border-[#F9F8F6]/10">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 font-bold">
                      {matchedCount} matching pieces
                    </span>
                    <button
                      onClick={() => setSelectedCollection(col)}
                      className="text-[11px] font-bold text-[#C4A484] group-hover:text-white transition flex items-center gap-1 uppercase tracking-widest cursor-pointer"
                    >
                      <span>Explore Outfit</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Lookbook Expansion Modal Detail */}
      {selectedCollection && (
        <div id="lookbook-modal-back" className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/70 backdrop-blur-sm p-4">
          <div className="bg-[#F9F8F6] rounded-none w-full max-w-4xl border-2 border-[#1A1A1A] overflow-hidden flex flex-col md:flex-row h-auto max-h-[90vh] shadow-[10px_10px_0px_0px_rgba(26,26,26,1)]">
            
            {/* Modal Cover Header */}
            <div className="md:w-5/12 relative bg-black shrink-0 text-white flex flex-col justify-end p-8 border-b-2 md:border-b-0 md:border-r-2 border-[#1A1A1A]">
              {/* Dynamic Cover background */}
              <img
                src={selectedCollection.coverUrl}
                alt={selectedCollection.name}
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover opacity-60"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/10" />

              <div className="relative z-10 space-y-4">
                <span className="font-serif text-xs italic text-[#C4A484] uppercase tracking-[0.2em] block">
                  {selectedCollection.season} Capsule
                </span>
                <h2 className="font-serif text-3xl font-black tracking-tight leading-none uppercase">
                  {selectedCollection.name}
                </h2>
                <p className="font-sans text-xs text-stone-300 leading-relaxed font-light">
                  {selectedCollection.description}
                </p>

                <div className="pt-4 border-t border-white/20">
                  <span className="text-[9px] tracking-widest font-mono text-gray-400 uppercase font-bold block mb-2">
                    Collection Action
                  </span>
                  <button
                    onClick={() => {
                      handleAddAllToCart(selectedCollection);
                      setSelectedCollection(null);
                    }}
                    className="w-full bg-[#1A1A1A] text-white border border-[#1A1A1A] py-3 rounded-none font-mono text-[10px] font-bold uppercase tracking-widest hover:bg-[#C4A484] hover:text-black transition duration-200 cursor-pointer"
                  >
                    Add Entire Look To Bag
                  </button>
                </div>
              </div>
            </div>

            {/* Lookbook Matchings Lists */}
            <div className="flex-1 p-6 md:p-8 flex flex-col justify-between overflow-y-auto">
              <div className="flex justify-between items-center border-b border-[#1A1A1A] pb-3.5 mb-5 shrink-0">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#C4A484]" />
                  <span className="font-mono text-[10px] uppercase tracking-wider text-[#1A1A1A] font-bold">Recipe Combinations</span>
                </div>
                <button
                  onClick={() => setSelectedCollection(null)}
                  className="p-1 px-3 border border-[#1A1A1A] bg-white text-stone-800 hover:bg-[#1A1A1A] hover:text-white font-mono text-[10px] font-bold uppercase tracking-widest transition cursor-pointer"
                >
                  Close
                </button>
              </div>

              {/* Items grid list */}
              <div className="space-y-4 flex-1 overflow-y-auto pr-1">
                {getCollectionProducts(selectedCollection).length === 0 ? (
                  <div className="py-12 text-center text-stone-400 font-mono text-xs flex flex-col items-center">
                    <ImageIcon className="w-8 h-8 text-stone-300 mb-2" />
                    <span>Matching database items are currently missing for this capsule.</span>
                  </div>
                ) : (
                  getCollectionProducts(selectedCollection).map((p) => (
                    <div
                      key={p.id}
                      className="p-3.5 border border-[#1A1A1A] rounded-none flex items-center justify-between gap-4 transition bg-white hover:bg-[#F9F8F6]"
                    >
                      <div className="flex items-center gap-4">
                        <img
                          src={p.imageUrl}
                          alt={p.name}
                          referrerPolicy="no-referrer"
                          className="w-12 h-16 object-cover rounded-none border border-[#1A1A1A] shrink-0"
                        />
                        <div className="min-w-0">
                          <span className="text-[9px] font-mono text-[#C4A484] font-bold uppercase block tracking-wider leading-none mb-1">
                            {p.category}
                          </span>
                          <h4 className="text-xs font-bold text-[#1A1A1A] leading-snug truncate">
                            {p.name}
                          </h4>
                          <span className="text-xs font-black text-[#1A1A1A] font-mono block mt-1">
                            ₹{p.price.toLocaleString()}
                          </span>
                        </div>
                      </div>

                      {/* Quick Item action bindings */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => toggleWishlist(p)}
                          className={`p-2 border border-[#1A1A1A] rounded-none transition cursor-pointer ${isProductInWishlist(p.id) ? 'bg-red-50 text-red-600' : 'bg-white text-neutral-400 hover:text-black'}`}
                          title="Save Style"
                        >
                          <Heart className="w-3.5 h-3.5 fill-current" />
                        </button>
                        <button
                          onClick={() => addToCart(p, "M", 1)}
                          disabled={p.inventory === 0}
                          className={`px-3 py-2 border border-[#1A1A1A] rounded-none font-sans text-[10px] font-bold uppercase tracking-widest transition cursor-pointer ${p.inventory === 0 ? 'bg-stone-200 text-stone-400 cursor-not-allowed' : 'bg-[#1A1A1A] text-white hover:bg-[#C4A484] hover:text-black'}`}
                        >
                          {p.inventory === 0 ? "Out" : "Add"}
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Back out label footer */}
              <div className="mt-5 pt-3.5 border-t border-[#1A1A1A]/10 flex justify-between items-center text-[9px] font-mono text-stone-500 shrink-0 font-bold uppercase tracking-widest">
                <span>TERMS & RESTRICTIONS APPLY</span>
                <span>COUTURA DIGITAL ATELIER</span>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
