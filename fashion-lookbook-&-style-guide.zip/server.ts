/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini API
const apiKey = process.env.GEMINI_API_KEY;
let ai: any = null;
if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini API initialized successfully.");
  } catch (err) {
    console.error("Error initializing Gemini API:", err);
  }
} else {
  console.log("GEMINI_API_KEY not configured or placeholder detected. Falling back to simulated styling recommendations.");
}

// In-Memory Database State
const USERS_DB = [
  { id: "u1", email: "kartheek@style.com", name: "PODDUTURI KARTHEEK REDDY", role: "admin", password: "123" },
  { id: "u2", email: "apoorva@style.com", name: "MUPPANA CHINMAYA APOORVA", role: "admin", password: "123" },
  { id: "u3", email: "guest@style.com", name: "Fashion Admirer", role: "user", password: "123" }
];

const PRODUCTS_DB = [
  {
    id: "p1",
    name: "Classic Double-Breasted Trench Coat",
    description: "A timeless, weather-resistant double-breasted outerwear tailored with refined shoulders, horn buttons, and an adjustable waist belt. Made of premium cotton-gabardine blend, this piece is the epitome of transitional styling.",
    category: "Outerwear",
    price: 8999,
    imageUrl: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=600&auto=format&fit=crop",
    occasion: "formal",
    season: "Autumn",
    inventory: 15
  },
  {
    id: "p2",
    name: "V-Neck Pleated Emerald Silk Dress",
    description: "An elegant Evening Maxi Dress custom crafted in heavy sand-washed silk. Embellished with delicate hand-pleated detailing and a low scoop back, draping effortlessly for high-profile elegant events.",
    category: "Dresses",
    price: 12499,
    imageUrl: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?q=80&w=600&auto=format&fit=crop",
    occasion: "evening",
    season: "Summer",
    inventory: 8
  },
  {
    id: "p3",
    name: "Oversized Utility Heavyweight Hoodie",
    description: "Crafted from a custom loopback french terry (450GSM). Built with reinforced seam lines, drop shoulder geometry, and double-lined hood architecture. A quintessential element for modern streetwear layout.",
    category: "Streetwear",
    price: 4499,
    imageUrl: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Winter",
    inventory: 24
  },
  {
    id: "p4",
    name: "Classic Sand Suede Chelsea Boots",
    description: "Individually handcrafted in Italy from premium suede leather. Hand-stitched welt structure paired with visual stretch goring panels and heavy-duty grip soles. Perfect for matching casual or utility outfit looks.",
    category: "Footwear",
    price: 7999,
    imageUrl: "https://images.unsplash.com/photo-1520639888713-7851133b1ed0?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Autumn",
    inventory: 12
  },
  {
    id: "p5",
    name: "Relaxed Premium Off-White Linen Shirt",
    description: "An airy resort silhouette made from 100% fine French flax linen. Featuring a camp collar detail, organic wood-grain buttons and pre-washed drape for ultimate travel comfort under open coastal sun.",
    category: "Shirts",
    price: 2999,
    imageUrl: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=600&auto=format&fit=crop",
    occasion: "resort",
    season: "Summer",
    inventory: 30
  },
  {
    id: "p6",
    name: "High-Waisted Tailored Pleated Trousers",
    description: "Elegantly constructed tailored trousers featuring sharp front creases, side button adjusters, and deep slash pockets. Fabricated with breathable merino wool blend for structural crisp look.",
    category: "Pants",
    price: 5499,
    imageUrl: "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=600&auto=format&fit=crop",
    occasion: "formal",
    season: "Spring",
    inventory: 18
  },
  {
    id: "p7",
    name: "Handcrafted Premium Hobo Shoulder Bag",
    description: "A luxurious visual classic crafted from soft pebbled calfskin. Curved minimal slouch form with an adjustable broad strap, dynamic secure zipper compartment, and gleaming solid brass hardware accessories.",
    category: "Accessories",
    price: 9499,
    imageUrl: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "All-Season",
    inventory: 10
  },
  {
    id: "p8",
    name: "Exquisite Cashmere Oversized Sweater",
    description: "Indulgent softness spun from Mongolian cashmere yarns. Elevated with a cozy ribbed mock neck collar, snug sleeves and a slouchy silhouette that layers over trench coats with effortless elegance.",
    category: "Knitwear",
    price: 11999,
    imageUrl: "https://images.unsplash.com/photo-1614975058789-41316d0e2e9c?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Winter",
    inventory: 7
  },
  {
    id: "p9",
    name: "Aesthetic Premium Wool Overcoat",
    description: "Heavy structural overcoat containing dense charcoal wool-melton weave. Features broad peak lapels, tailored visual welt styling and a luxurious full satin inner lining to shield in style.",
    category: "Outerwear",
    price: 14999,
    imageUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=600&auto=format&fit=crop",
    occasion: "formal",
    season: "Winter",
    inventory: 8
  },
  {
    id: "p10",
    name: "Mulberry Silk Drape Halter Dress",
    description: "Cut on the bias for stunning drape flow, this backless midi dress is constructed with premium Mulberry silk yarns. Ideal for art gallery walks and cocktail lounge events.",
    category: "Dresses",
    price: 10999,
    imageUrl: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=600&auto=format&fit=crop",
    occasion: "evening",
    season: "Summer",
    inventory: 14
  },
  {
    id: "p11",
    name: "Vintage Garment-Dyed Utility Jacket",
    description: "Crafted from sturdy canvas cotton featuring triple-stitch seam lines, roomy utility 3D pockets, and detailed copper rivet closures. A masterpiece of functional streetwear accents.",
    category: "Outerwear",
    price: 6499,
    imageUrl: "https://images.unsplash.com/photo-1617137968427-85924c800a22?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Autumn",
    inventory: 12
  },
  {
    id: "p12",
    name: "Clean Minimalist Leather Sneakers",
    description: "Meticulously crafted with full-grain calfskin leather, reinforced vulcanized rubber margins, and premium cork insoles that adapt to your foot's architectural gait pattern over time.",
    category: "Footwear",
    price: 6999,
    imageUrl: "https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Spring",
    inventory: 20
  },
  {
    id: "p13",
    name: "Stone-Washed Denim Heavy Trucker",
    description: "Tailored out of massive 14oz Japanese raw denim fabric. Pre-shrunk weave featuring customized dark metal buttons and beautifully balanced architectural lines.",
    category: "Streetwear",
    price: 5299,
    imageUrl: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Autumn",
    inventory: 11
  },
  {
    id: "p14",
    name: "Architectural Oxford Button-Down",
    description: "Traditional heavy Oxford weave stitched to sharp precision. Elegant button-down collar profile that delivers structural integrity, layerable comfortably inside thick wool sweaters.",
    category: "Shirts",
    price: 3299,
    imageUrl: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=600&auto=format&fit=crop",
    occasion: "formal",
    season: "Spring",
    inventory: 15
  },
  {
    id: "p15",
    name: "Relaxed Aesthetic Slub Chinos",
    description: "A gorgeous slub cotton-twill blend that provides exquisite surface texture play. Tailored with neat pocket outlines and a casual tapered leg form for modern daily use.",
    category: "Pants",
    price: 3799,
    imageUrl: "https://images.unsplash.com/photo-1473968512647-3e447244af8f?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Spring",
    inventory: 16
  },
  {
    id: "p16",
    name: "Minimalist Brass-Rim Aviators",
    description: "Exquisitely engineered lightweight sunglasses built with sand-brushed brass hardware frames, protective tinted acetate lenses, and elegant hand-beveled endpoints.",
    category: "Accessories",
    price: 2499,
    imageUrl: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?q=80&w=600&auto=format&fit=crop",
    occasion: "resort",
    season: "Summer",
    inventory: 25
  },
  {
    id: "p17",
    name: "Alpaca Blend Ribbed Chunky Cardigan",
    description: "Indulgently heavy and warm, knit out of superior alpaca-merino blend fibers. Boasts detailed tortoiseshell buttons and deep cozy hand-warmer knit pockets.",
    category: "Knitwear",
    price: 9299,
    imageUrl: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Winter",
    inventory: 9
  },
  {
    id: "p18",
    name: "Cropped Sculptural Wool Blazer",
    description: "An elegant asymmetrical silhouette tailored with sharp notch shoulders, detailed sleeve buttons, and a structured waistline. Brings clean architectural elegance to formal events.",
    category: "Outerwear",
    price: 8499,
    imageUrl: "https://images.unsplash.com/photo-1548624149-f9b1859aa700?q=80&w=600&auto=format&fit=crop",
    occasion: "formal",
    season: "Autumn",
    inventory: 10
  },
  {
    id: "p19",
    name: "Organic Flax Linen Utility Jumpsuit",
    description: "A flowy silhouette containing clean lines, adjustable fabric waist belt, and deep cargo-inspired visual pockets. Epitome of breezy travel and resort luxury.",
    category: "Dresses",
    price: 7499,
    imageUrl: "https://images.unsplash.com/photo-1581044777550-4cfa60707c03?q=80&w=600&auto=format&fit=crop",
    occasion: "resort",
    season: "Summer",
    inventory: 13
  },
  {
    id: "p20",
    name: "Handcrafted Leather Derby Shoes",
    description: "A clean classic constructed with fine vegetable-tanned Italian leather. Elegant waxed cords paired with cushioned cork styling for all-day comfort with architectural suits.",
    category: "Footwear",
    price: 8999,
    imageUrl: "https://images.unsplash.com/photo-1531310197839-ccf54634509e?q=80&w=600&auto=format&fit=crop",
    occasion: "formal",
    season: "All-Season",
    inventory: 15
  },
  {
    id: "p21",
    name: "Striped Silk-Linen Camp Shirt",
    description: "Infused with neutral pinstripe lines, this resort shirt blends cooling slub flax with luxurious raw silk. Camp collar finish with hand-carved wood buttons.",
    category: "Shirts",
    price: 3999,
    imageUrl: "https://images.unsplash.com/photo-1607345366928-199ea26cfe3e?q=80&w=600&auto=format&fit=crop",
    occasion: "resort",
    season: "Summer",
    inventory: 22
  },
  {
    id: "p22",
    name: "Wide-Leg Linen Drawstring Trousers",
    description: "Unbelievably breathable wide-leg trousers containing elastic drawstrings. Perfect for high comfort on hot days, seaside strolls or stylish lounging.",
    category: "Pants",
    price: 3499,
    imageUrl: "https://images.unsplash.com/photo-1509551388413-e18d0ac5d495?q=80&w=600&auto=format&fit=crop",
    occasion: "resort",
    season: "Summer",
    inventory: 19
  },
  {
    id: "p23",
    name: "Soft Brushed Wool Oversized Scarf",
    description: "Woven meticulously with pure virgin lambswool, finalized with handcrafted fringe borders. Adds an exquisite cozy aesthetic layer in rich neutral tones.",
    category: "Accessories",
    price: 1899,
    imageUrl: "https://images.unsplash.com/photo-1520903928273-0f4432a28db3?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Winter",
    inventory: 30
  },
  {
    id: "p24",
    name: "Heirloom Cable-Knit Crewneck",
    description: "Traditional heavy stitch detailing in rich cream white color. A dense merino wool structure featuring beautiful heritage braid patterns that elevate classic outerwear layers.",
    category: "Knitwear",
    price: 6999,
    imageUrl: "https://images.unsplash.com/photo-1614975058789-41316d0e2e9c?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Winter",
    inventory: 14
  },
  {
    id: "p25",
    name: "Water-Resistant Technical Canvas Parka",
    description: "Elegantly functional protective coat containing micro-membrane weather sealing, detailed zip guards, and an adjustable structured hood structure.",
    category: "Outerwear",
    price: 11499,
    imageUrl: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Winter",
    inventory: 8
  },
  {
    id: "p26",
    name: "Heavy-Crepe Velvet Gown",
    description: "A majestic asymmetric visual evening gown structured from high-density silk velvet. Form-fitting waist leading into a subtle pool drape. Pure elite drama.",
    category: "Dresses",
    price: 15999,
    imageUrl: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=600&auto=format&fit=crop",
    occasion: "evening",
    season: "Winter",
    inventory: 5
  },
  {
    id: "p27",
    name: "Aesthetic Graphic Heavyweight Tee",
    description: "Clean organic cotton shirt (280GSM) boasting minimalistic typography chest prints. Combines a structural drop-shoulder profile with clean styling.",
    category: "Streetwear",
    price: 1999,
    imageUrl: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Spring",
    inventory: 40
  },
  {
    id: "p28",
    name: "Handcrafted Suede Penny Loafers",
    description: "Crafted out of velvety moss suede leather, featuring delicate top stitching and traditional slip-on styling. Provides sophisticated luxury contrast.",
    category: "Footwear",
    price: 7499,
    imageUrl: "https://images.unsplash.com/photo-1533867617858-e7b97e060509?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Spring",
    inventory: 16
  },
  {
    id: "p29",
    name: "Mandarin Collar Slub Slit Shirt",
    description: "Unique aesthetic shirt stitched from hand-woven cotton checks. Clean half-placket details paired with relaxed side visual slits.",
    category: "Shirts",
    price: 2599,
    imageUrl: "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Summer",
    inventory: 28
  },
  {
    id: "p30",
    name: "Tailored Slim-Fit Merino Pants",
    description: "Emanates sheer elegance with smart structural lines. Finished with a hidden hook-and-bar front closure and functional back welt pockets.",
    category: "Pants",
    price: 4999,
    imageUrl: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=600&auto=format&fit=crop",
    occasion: "formal",
    season: "Autumn",
    inventory: 15
  },
  {
    id: "p31",
    name: "Minimalist Polished Silver Cuff",
    description: "Solid sterling silver cuff displaying brushed satin finishes and rounded endpoints. A subtle, high-end highlight to clean suit sleeve layouts.",
    category: "Accessories",
    price: 1499,
    imageUrl: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?q=80&w=600&auto=format&fit=crop",
    occasion: "formal",
    season: "All-Season",
    inventory: 35
  },
  {
    id: "p32",
    name: "Merino Wool Crewneck Base Layer",
    description: "Supremely soft, lightweight thermal luxury sweater. Sourced from organic farms, ideal for thin sophisticated layering inside heavy coats.",
    category: "Knitwear",
    price: 4299,
    imageUrl: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Autumn",
    inventory: 18
  },
  {
    id: "p33",
    name: "Plush Sheepskin Sherpa Jacket",
    description: "Crafted with dense recycled fiber shearling fabric, styled with premium faux suede elements and solid zipper detailing.",
    category: "Outerwear",
    price: 16499,
    imageUrl: "https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Winter",
    inventory: 6
  },
  {
    id: "p34",
    name: "Aesthetic Pleated Utility Dress",
    description: "Structural dress made with strong fine cotton-twill. Clean crisp pleats framing the waistline paired with beautiful military styled buttons.",
    category: "Dresses",
    price: 6299,
    imageUrl: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Autumn",
    inventory: 12
  },
  {
    id: "p35",
    name: "Oversized Acid-Wash Fleece Joggers",
    description: "Cozy streetwear elements spun from dense brushed fleece. Displays an aesthetic vintage cloud wash finish and thick ribbed cuffs.",
    category: "Streetwear",
    price: 3199,
    imageUrl: "https://images.unsplash.com/photo-1551854838-212c50b4c184?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Winter",
    inventory: 20
  },
  {
    id: "p36",
    name: "Suede Platform Lug-Sole Boots",
    description: "Chunky yet refined Chelsea silhouettes containing elastic side gussets, beautiful textured suede, and premium high-gripped soles.",
    category: "Footwear",
    price: 8499,
    imageUrl: "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Winter",
    inventory: 9
  },
  {
    id: "p37",
    name: "Asymmetric Drape Poplin Shirt",
    description: "Crisp cotton poplin designed to flow with visual asymmetry. Unique structured wrap closure giving a dramatic contemporary feel.",
    category: "Shirts",
    price: 3499,
    imageUrl: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=600&auto=format&fit=crop",
    occasion: "formal",
    season: "Spring",
    inventory: 15
  },
  {
    id: "p38",
    name: "Pintuck Tailored Linen Trousers",
    description: "Premium slub-textured pants featuring structural pintuck seams down the front, side buckle tabs, and breathable linen weave.",
    category: "Pants",
    price: 3999,
    imageUrl: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Summer",
    inventory: 14
  },
  {
    id: "p39",
    name: "Full-Grain Leather Minimalist Wallet",
    description: "Sophisticated bi-fold structure designed out of raw vegetable-tanned leather. Fits multiple cards cleanly and darkens beautifully over time.",
    category: "Accessories",
    price: 2199,
    imageUrl: "https://images.unsplash.com/photo-1627123424574-724758594e93?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "All-Season",
    inventory: 40
  },
  {
    id: "p40",
    name: "Quarter-Zip Textured Knit Pullover",
    description: "Spun from combed waffle cotton loops. Clean silver zipper finish paired with beautiful snug rib boundaries along the cuffs.",
    category: "Knitwear",
    price: 5999,
    imageUrl: "https://images.unsplash.com/photo-1519242220831-09410926fbff?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Spring",
    inventory: 22
  },
  {
    id: "p41",
    name: "Suede Minimalist Biker Jacket",
    description: "A gorgeous, streamlined aesthetic jacket designed out of smooth heavy goat suede. Features dynamic asymmetric visual zips and metal buttons.",
    category: "Outerwear",
    price: 13999,
    imageUrl: "https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Autumn",
    inventory: 7
  },
  {
    id: "p42",
    name: "Organic Raw-Knit Slip Dress",
    description: "Form-flattering slip dress spun with a beautiful raw textured cotton-bamboo blend, detailed with delicate thin shoulder straps.",
    category: "Dresses",
    price: 9899,
    imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=600&auto=format&fit=crop",
    occasion: "evening",
    season: "Summer",
    inventory: 11
  },
  {
    id: "p43",
    name: "Raw-Edge Visual Boxy Sweatshirt",
    description: "Heavy french terry crop sweatshirt with clean loop-back textures, rolled visual sleeve edges, and structural visual box shapes.",
    category: "Streetwear",
    price: 3899,
    imageUrl: "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Winter",
    inventory: 18
  },
  {
    id: "p44",
    name: "Woven Cross-Strap Leather Sandals",
    description: "Beautiful resort slide sandals woven entirely of premium flexible straps, containing a natural leather sole that stays cool.",
    category: "Footwear",
    price: 4299,
    imageUrl: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?q=80&w=600&auto=format&fit=crop",
    occasion: "resort",
    season: "Summer",
    inventory: 15
  },
  {
    id: "p45",
    name: "Pima Cotton Minimalist Luxury Tees",
    description: "Set of three premium t-shirts crafted from authentic grade-A Peruvian Pima cotton. Breathable, silk-soft texture for effortless base layouts.",
    category: "Shirts",
    price: 2899,
    imageUrl: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "All-Season",
    inventory: 25
  },
  {
    id: "p46",
    name: "Tactical Utility Cargo Chinos",
    description: "Contemporary cargo styling with tapered cuffs. Includes stealth flat cargo panels and deep visual storage, with adjustable strap closures.",
    category: "Pants",
    price: 4499,
    imageUrl: "https://images.unsplash.com/photo-1517423568366-8b83523034fd?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Autumn",
    inventory: 14
  },
  {
    id: "p47",
    name: "Aesthetic Engraved Solid-Brass Belt",
    description: "Full-grain thick saddle leather fitted with an antiqued sand-brushed solid brass buckle closure. Essential styling classic.",
    category: "Accessories",
    price: 1699,
    imageUrl: "https://images.unsplash.com/photo-1624222247566-7f8242224756?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "All-Season",
    inventory: 20
  },
  {
    id: "p48",
    name: "Fisherman Rib Merino Beanie",
    description: "Aesthetic snug visual beanie woven of heavy merino threads, providing ideal structure and natural warmth.",
    category: "Accessories",
    price: 1299,
    imageUrl: "https://images.unsplash.com/photo-1576871337622-98d48d4aa53e?q=80&w=600&auto=format&fit=crop",
    occasion: "street",
    season: "Winter",
    inventory: 50
  },
  {
    id: "p49",
    name: "Mohair Aesthetic Plaid Shacket",
    description: "Highly fuzzy mohair weave blended with autumn visual checks, detailed with thick silver buttons and oversized pocket accents.",
    category: "Knitwear",
    price: 8299,
    imageUrl: "https://images.unsplash.com/photo-1617137968427-85924c800a22?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Autumn",
    inventory: 10
  },
  {
    id: "p50",
    name: "Brushed Solid Cashmere Wrap Scarf",
    description: "Generously sized shawl wrap woven in luxurious knit cashmere yarns. Delivers immediate warming elegance with broad drape lines.",
    category: "Knitwear",
    price: 7999,
    imageUrl: "https://images.unsplash.com/photo-1520903928273-0f4432a28db3?q=80&w=600&auto=format&fit=crop",
    occasion: "casual",
    season: "Winter",
    inventory: 15
  }
];

const COLLECTIONS_DB = [
  {
    id: "c1",
    name: "Autumnal Resonance",
    description: "Warm, eye-safe neutral layering designed to combat crisp winds. Heavy knits, clean suede boots, and timeless gabardine trench coat silhouettes define this seasonal aesthetic.",
    season: "Autumn",
    coverUrl: "https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=1200&auto=format&fit=crop",
    productIds: ["p1", "p4", "p8"],
    isEditorial: true
  },
  {
    id: "c2",
    name: "Resort Coastline Luxury",
    description: "Infused with airy linens and sand-washed silks that capture coastal sea breezes. Handbags and flowy drapes tailored for long elegant sunsets, ocean dinners and seaside holidays.",
    season: "Summer",
    coverUrl: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?q=80&w=1200&auto=format&fit=crop",
    productIds: ["p2", "p5", "p7"],
    isEditorial: true
  },
  {
    id: "c3",
    name: "Metropolitan Streetwear Volume I",
    description: "A rugged, functional layout tailored for dynamic urban exploration. Reinforced heavyweight loops, bold drop-shoulders and practical accessories providing perfect structural rhythm.",
    season: "Winter",
    coverUrl: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1200&auto=format&fit=crop",
    productIds: ["p3", "p4", "p7"],
    isEditorial: true
  }
];

const ORDERS_DB: any[] = [];

// API ENDPOINTS

// 1. AUTH API
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = USERS_DB.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
  if (!user) {
    return res.status(401).json({ error: "Invalid email or password credentials." });
  }
  // Return user structure
  res.json({
    user: { id: user.id, email: user.email, name: user.name, role: user.role }
  });
});

app.post("/api/auth/register", (req, res) => {
  const { email, name, password } = req.body;
  if (!email || !name || !password) {
    return res.status(400).json({ error: "Please provide all required registration fields." });
  }
  const exists = USERS_DB.some(u => u.email.toLowerCase() === email.toLowerCase());
  if (exists) {
    return res.status(400).json({ error: "Email address is already in use." });
  }
  const newUser = {
    id: "u" + (USERS_DB.length + 1),
    email: email.toLowerCase(),
    name,
    role: "user" as const,
    password
  };
  USERS_DB.push(newUser);
  res.status(201).json({
    user: { id: newUser.id, email: newUser.email, name: newUser.name, role: newUser.role }
  });
});

// 2. PRODUCTS API
app.get("/api/products", (req, res) => {
  res.json(PRODUCTS_DB);
});

// Admin-protected product addition
app.post("/api/products", (req, res) => {
  const { name, description, category, price, imageUrl, occasion, season, inventory } = req.body;
  if (!name || !category || !price) {
    return res.status(400).json({ error: "Product name, category, and price are required." });
  }
  const newProduct = {
    id: "p" + (PRODUCTS_DB.length + 1),
    name,
    description: description || "Gorgeous design piece from our style collections.",
    category,
    price: Number(price),
    imageUrl: imageUrl || "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=600&auto=format&fit=crop",
    occasion: occasion || "casual",
    season: season || "All-Season",
    inventory: Number(inventory) || 10
  };
  PRODUCTS_DB.push(newProduct);
  res.status(201).json(newProduct);
});

// Admin-protected product update
app.put("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const index = PRODUCTS_DB.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Product not found." });
  }
  const updatedValue = { ...PRODUCTS_DB[index], ...req.body };
  PRODUCTS_DB[index] = updatedValue;
  res.json(updatedValue);
});

// Admin-protected product delete
app.delete("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const index = PRODUCTS_DB.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Product not found." });
  }
  const removed = PRODUCTS_DB.splice(index, 1);
  res.json({ message: "Product deleted successfully.", product: removed[0] });
});

// 3. LOOKBOOKS (COLLECTIONS) API
app.get("/api/lookbooks", (req, res) => {
  res.json(COLLECTIONS_DB);
});

// Create collection
app.post("/api/lookbooks", (req, res) => {
  const { name, description, season, coverUrl, productIds } = req.body;
  if (!name || !season) {
    return res.status(400).json({ error: "Lookbook title and season are required." });
  }
  const newLookbook = {
    id: "c" + (COLLECTIONS_DB.length + 1),
    name,
    description: description || "Fresh style pairings handpicked by the design team.",
    season,
    coverUrl: coverUrl || "https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=1200&auto=format&fit=crop",
    productIds: Array.isArray(productIds) ? productIds : [],
    isEditorial: false
  };
  COLLECTIONS_DB.push(newLookbook);
  res.status(201).json(newLookbook);
});

// Update Collection
app.put("/api/lookbooks/:id", (req, res) => {
  const { id } = req.params;
  const index = COLLECTIONS_DB.findIndex(c => c.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Lookbook not found." });
  }
  const updated = { ...COLLECTIONS_DB[index], ...req.body };
  COLLECTIONS_DB[index] = updated;
  res.json(updated);
});

// Delete Collection
app.delete("/api/lookbooks/:id", (req, res) => {
  const { id } = req.params;
  const index = COLLECTIONS_DB.findIndex(c => c.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Lookbook not found." });
  }
  const removed = COLLECTIONS_DB.splice(index, 1);
  res.json({ message: "Lookbook deleted successfully.", collection: removed[0] });
});

// 4. ORDERS & CHECKOUT API
app.get("/api/orders", (req, res) => {
  res.json(ORDERS_DB);
});

app.post("/api/orders", (req, res) => {
  const { userId, buyerName, email, items, subtotal, shipping, tax, total, address, payment } = req.body;
  if (!items || items.length === 0 || !address || !payment) {
    return res.status(400).json({ error: "Missing checkout parameters." });
  }
  
  // Deduct inventory
  for (const item of items) {
    const prod = PRODUCTS_DB.find(p => p.id === item.product.id);
    if (prod) {
      prod.inventory = Math.max(0, prod.inventory - item.quantity);
    }
  }

  const newOrder = {
    id: "ord_" + Math.random().toString(36).substr(2, 9),
    userId: userId || "guest",
    buyerName: buyerName || "Guest User",
    email: email || "guest@style.com",
    items,
    subtotal: Number(subtotal),
    shipping: Number(shipping),
    tax: Number(tax),
    total: Number(total),
    address,
    payment,
    status: "processing",
    date: new Date().toISOString()
  };
  
  ORDERS_DB.push(newOrder);
  res.status(201).json(newOrder);
});

// 5. GEMINI AI STYLIST API
app.post("/api/stylist/suggest", async (req, res) => {
  const { occasion, season, colorPreference, temperature, additionalPrompt } = req.body;

  const prompt = `You are an elite, highly professional personal fashion designer and chief high-fashion stylist.
Please compile a custom, bespoke Styling Suggestion and Outfit Recipe in Markdown.
Input details:
- Desired Occasion: ${occasion || "Any Occasion"}
- Season / Weather: ${season || "All-Season"}
- Preferred Color Palette: ${colorPreference || "Neutral Chic (Cream, Taupe, Charcoal)"}
- Temperature/Climate Context: ${temperature || "Mild"}
- Extra Notes: ${additionalPrompt || "Focus on timeless elegant silhouettes."}

Structure your response into the following clear professional sections:
1. **The Style Aesthetic**: Describe the vibe, the lines, materials, and overall mood (e.g., Parisian street style, relaxed seaside resort drapes, crisp architectural tailoring).
2. **The Signature Outfit Recipe**: Detail the exact garments of the core look: Top, Bottoms/Dress, Layering pieces (outerwear), footwear, and specific accessory details (bags, watches, sunglasses, scarves).
3. **The Palette & Contrast Theory**: Explain why this color pairing works and how to balance contrasts.
4. **Day-to-Night Transition Tip**: One specific, creative hack to dress this style up or down using small transformations.

Use highly polished fashion terminology (e.g., negative space, sand-washed drape, high-contrast texture play, proportional play, casual luxury). Avoid generic advice. Try to keep the entire response within 400 words.`;

  if (ai) {
    try {
      console.log("Calling Gemini API with prompt...");
      const genAIResponse = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt
      });
      const generatedText = genAIResponse.text;
      return res.json({ recommendation: generatedText });
    } catch (err: any) {
      console.error("Gemini API call failed:", err);
      return res.status(500).json({
        error: "Failed to connect to AI styling engine.",
        details: err?.message || "Verify your API key in settings."
      });
    }
  } else {
    // Elegant fallback simulation if API key is not provided.
    // Extremely detailed and aesthetic fallback matching the guidelines perfectly!
    console.log("Simulating stylist response...");
    const simulatedResponse = `### **The Style Aesthetic: ${occasion.toUpperCase()} TRANSITION**

This look centers on **elevated structural minimalist luxury**. We merge breezy textures with crisp tailoring, evoking a highly sophisticated European street visual that balanced comfort with high-fashion intent.

---

### **The Signature Outfit Recipe**

*   **Core Base**: A sand-washed premium off-white linen shirt unbuttoned slightly for effortlessness, tucked cleanly into structured high-waisted pleated trousers in charcoal or dark taupe.
*   **The Power Layering**: An oversized double-breasted trench coat belted loosely behind, providing vertical architectural lines and movement.
*   **Footwear selection**: Handmade suede Chelsea boots in warm sand or vintage loafers.
*   **Accessories**: Sleek leather hobo bag with gold metal accents, geometric dark sunglasses, and a brushed gold buckle belt that catches sunlight.

---

### **The Palette & Contrast Theory**

The contrast centers on a sophisticated interplay of warmth and depth. Balancing warm cream linen with cool charcoal tailored pants creates high-impact visual depth without overcomplicating with loud colors. 

---

### **Day-to-Night Transition Tip**

*Detach the casual oversized trench coat and swap the leather hobo bag for a sleek structured envelope clutch. Roll back the sleeves of the linen shirt and add a delicate layered gold chain necklace — shifting from relaxed afternoon resort elegance into curated private evening bistro lounge ready.*`;
    
    // Simulate slight network delay for premium feel
    setTimeout(() => {
      res.json({ recommendation: simulatedResponse });
    }, 1000);
  }
});

// VITE MIDDLEWARE SETUP
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express server successfully running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
