/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { useApp } from "./AppContext";
import { X, CreditCard, ShieldCheck, ShoppingBag, Landmark, ArrowLeft, Check, Compass } from "lucide-react";

export default function CheckoutModal({
  isOpen,
  onClose
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const { cart, placeOrder, currentUser, isLoading } = useApp();

  // Address Formulation info
  const [fullName, setFullName] = useState(currentUser?.name || "");
  const [street, setStreet] = useState("102 Fashion Boulevard, High Street");
  const [city, setCity] = useState("Vogue District");
  const [state, setState] = useState("Atelier Center");
  const [zipCode, setZipCode] = useState("500015");
  const [country, setCountry] = useState("India");

  // Payment states
  const [payMethod, setPayMethod] = useState<'card' | 'paypal' | 'upi'>('card');
  const [cardNumber, setCardNumber] = useState("4111 2222 3333 4444");
  const [cardExpiry, setCardExpiry] = useState("12/28");
  const [cardCvv, setCardCvv] = useState("321");

  // Order success receipt states
  const [placedOrder, setPlacedOrder] = useState<any | null>(null);

  if (!isOpen) return null;

  const subtotal = cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  const shipping = subtotal > 3000 ? 0 : 150;
  const tax = Math.round(subtotal * 0.08 * 100) / 100;
  const grandTotal = subtotal + shipping + tax;

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const address = {
      fullName,
      street,
      city,
      state,
      zipCode,
      country
    };

    const payment = {
      method: payMethod,
      cardLast4: payMethod === 'card' ? cardNumber.split(' ').pop() || "4444" : undefined
    };

    const result = await placeOrder(address, payment);
    if (result) {
      setPlacedOrder(result);
    }
  };

  return (
    <div id="checkout-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/60 backdrop-blur-sm p-4">
      <div className="bg-[#F9F8F6] rounded-none w-full max-w-4xl border-2 border-[#1A1A1A] overflow-hidden flex flex-col md:flex-row h-auto max-h-[92vh] shadow-[10px_10px_0px_0px_rgba(26,26,26,1)]">
        
        {placedOrder ? (
          /* SECTION SUCCESS REAL INVOICE RECEIPT */
          <div className="flex-1 p-8 text-center flex flex-col items-center justify-center max-w-2xl mx-auto space-y-6">
            <div className="w-16 h-16 border-2 border-[#1A1A1A] bg-white text-emerald-600 flex items-center justify-center rounded-none shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]">
              <Check className="w-8 h-8 stroke-[3]" />
            </div>

            <div className="space-y-2">
              <span className="font-mono text-[9px] tracking-widest text-[#C4A484] font-bold block uppercase">ORDER VERIFIED & DISPATCHED</span>
              <h2 className="font-serif text-3xl font-black text-[#1A1A1A] uppercase tracking-tight">Thank you, {placedOrder.buyerName}!</h2>
              <p className="font-mono text-xs text-[#1A1A1A]/60">Order ID: <span className="font-mono text-black font-semibold uppercase">{placedOrder.id}</span></p>
            </div>

            <p className="font-sans text-xs text-stone-600 max-w-md mx-auto leading-relaxed">
              Your fashion lookbook order compilation was placed successfully. All sizing dimensions are registered in the Atelier system.
            </p>

            {/* In-Memory Database order details card */}
            <div className="w-full bg-white border border-[#1A1A1A] rounded-none p-5 text-left text-xs font-mono space-y-4 max-w-md shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
              <span className="block text-[10px] uppercase tracking-widest font-bold text-[#C4A484] border-b border-[#1A1A1A]/10 pb-2">
                Order Invoice Summary Sheet
              </span>
              
              <div className="max-h-[140px] overflow-y-auto divide-y divide-[#1A1A1A]/10 pr-1.5">
                {placedOrder.items.map((item: any, id: number) => (
                  <div key={id} className="py-2.5 flex justify-between items-center text-stone-700">
                    <div>
                      <span className="font-bold text-[#1A1A1A] uppercase text-[11px]">{item.product.name}</span>
                      <span className="text-[10px] text-stone-400 ml-2">Size {item.size} × {item.quantity}</span>
                    </div>
                    <span className="font-bold text-black">₹{(item.product.price * item.quantity).toLocaleString()}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-[#1A1A1A]/10 pt-3 space-y-1.5 text-stone-500 text-[10px]">
                <div className="flex justify-between">
                  <span>Shipping Destination</span>
                  <span className="text-[#1A1A1A] font-medium">#{placedOrder.address.city}, {placedOrder.address.country}</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment Gateway Authorization</span>
                  <span className="text-[#1A1A1A] font-bold uppercase">{placedOrder.payment.method} (*{placedOrder.payment.cardLast4 || "UPI"})</span>
                </div>
                <div className="flex justify-between text-black font-black pt-2 text-[11px] border-t border-dashed border-[#1A1A1A]/20">
                  <span>Grand Total</span>
                  <span>₹{placedOrder.total.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <button
              id="success-dismiss-btn"
              onClick={() => {
                setPlacedOrder(null);
                onClose();
              }}
              className="px-8 py-3.5 border border-[#1A1A1A] bg-[#1A1A1A] text-white hover:bg-[#C4A484] hover:text-black transition rounded-none font-mono text-[10px] uppercase tracking-widest font-bold cursor-pointer"
            >
              Return to Catalog
            </button>
          </div>
        ) : (
          /* PRIMARY FORM UI */
          <>
            {/* Left Module: Address Input Formulation & Payment Selection */}
            <form onSubmit={handleCheckoutSubmit} className="flex-1 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto bg-white">
              <div>
                <div className="flex items-center gap-1.5 mb-6 text-stone-400 hover:text-black cursor-pointer transition" onClick={onClose}>
                  <ArrowLeft className="w-4 h-4" />
                  <span className="font-mono text-[9px] font-bold uppercase tracking-wider">Back out</span>
                </div>

                <div className="mb-6">
                  <span className="font-mono text-[9px] font-bold text-[#C4A484] tracking-wider uppercase block">Terminal Port: Muppana Chinmaya Apoorva (2520030078)</span>
                  <h2 className="font-serif text-2xl font-black text-[#1A1A1A] uppercase tracking-tight">Secure checkout</h2>
                </div>

                <div className="space-y-5">
                  {/* Address Section */}
                  <div className="space-y-3">
                    <span className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400">Couriers Destination Address</span>
                    
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-stone-400 uppercase tracking-wider mb-1.5">Full Addressee Name</label>
                      <input
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="E.g. Muppana Chinmaya Apoorva"
                        className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-[9px] font-mono font-bold text-stone-400 uppercase tracking-wider mb-1.5">Street Address</label>
                      <input
                        type="text"
                        value={street}
                        onChange={(e) => setStreet(e.target.value)}
                        className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3.5">
                      <div>
                        <label className="block text-[9px] font-mono font-bold text-stone-400 uppercase tracking-wider mb-1.5">City District</label>
                        <input
                          type="text"
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] font-mono font-bold text-stone-400 uppercase tracking-wider mb-1.5">Postal Zip Code</label>
                        <input
                          type="text"
                          value={zipCode}
                          onChange={(e) => setZipCode(e.target.value)}
                          placeholder="500015"
                          className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none"
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Payment selection tabs */}
                  <div className="space-y-3 pt-2">
                    <span className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400">Atelier Payment Gate</span>
                    
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => setPayMethod('card')}
                        className={`py-2 px-3 border rounded-none flex items-center justify-center gap-1.5 transition cursor-pointer ${payMethod === 'card' ? 'border-[#1A1A1A] bg-[#1A1A1A] text-white font-bold' : 'border-[#1A1A1A]/20 text-stone-500 bg-white hover:border-[#1A1A1A] hover:text-[#1A1A1A]'}`}
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span className="font-mono text-[10px] uppercase font-bold">Card</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPayMethod('upi')}
                        className={`py-2 px-3 border rounded-none flex items-center justify-center gap-1.5 transition cursor-pointer ${payMethod === 'upi' ? 'border-[#1A1A1A] bg-[#1A1A1A] text-white font-bold' : 'border-[#1A1A1A]/20 text-stone-500 bg-white hover:border-[#1A1A1A] hover:text-[#1A1A1A]'}`}
                      >
                        <Landmark className="w-3.5 h-3.5" />
                        <span className="font-mono text-[10px] uppercase font-bold">UPI</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPayMethod('paypal')}
                        className={`py-2 px-3 border rounded-none flex items-center justify-center gap-1.5 transition cursor-pointer ${payMethod === 'paypal' ? 'border-[#1A1A1A] bg-[#1A1A1A] text-white font-bold' : 'border-[#1A1A1A]/20 text-stone-500 bg-white hover:border-[#1A1A1A] hover:text-[#1A1A1A]'}`}
                      >
                        <Compass className="w-3.5 h-3.5" />
                        <span className="font-mono text-[10px] uppercase font-bold">PayPal</span>
                      </button>
                    </div>

                    {payMethod === 'card' ? (
                      <div className="space-y-3 bg-[#F9F8F6] p-4 border border-[#1A1A1A] rounded-none">
                        <div>
                          <label className="block text-[9px] font-mono font-bold text-stone-400 uppercase tracking-widest mb-1.5">Card Number</label>
                          <input
                            type="text"
                            value={cardNumber}
                            onChange={(e) => setCardNumber(e.target.value)}
                            className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:bg-[#F9F8F6]"
                            required
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[9px] font-mono font-bold text-stone-400 uppercase tracking-widest mb-1.5">Expiry Date</label>
                            <input
                              type="text"
                              value={cardExpiry}
                              onChange={(e) => setCardExpiry(e.target.value)}
                              className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:bg-[#F9F8F6]"
                              required
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-mono font-bold text-[#1A1A1A] uppercase tracking-widest mb-1.5 font-bold">CVV Security</label>
                            <input
                              type="password"
                              value={cardCvv}
                              onChange={(e) => setCardCvv(e.target.value)}
                              className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2 text-xs font-mono font-bold focus:outline-none focus:bg-[#F9F8F6]"
                              required
                            />
                          </div>
                        </div>
                      </div>
                    ) : payMethod === 'upi' ? (
                      <div className="bg-[#C4A484]/10 border border-[#C4A484] p-4 rounded-none flex items-center gap-3">
                        <Landmark className="w-5 h-5 text-[#C4A484] shrink-0" />
                        <p className="font-sans text-xs text-stone-800 leading-snug">
                          UPI QR Code generation is ready. Secure checkout compiles orders instantly post submission.
                        </p>
                      </div>
                    ) : (
                      <div className="bg-[#F9F8F6] border border-[#1A1A1A]/10 p-4 rounded-none text-center">
                        <span className="font-mono text-xs text-stone-500">PayPal integration handles instant forwarding.</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-8 border-t border-[#1A1A1A]/10 pt-5">
                <button
                  id="checkout-submit-btn"
                  type="submit"
                  disabled={isLoading || cart.length === 0}
                  className="w-full py-4 bg-[#1A1A1A] text-white hover:bg-[#C4A484] hover:text-black border border-[#1A1A1A] transition duration-200 font-mono text-[10px] uppercase font-bold tracking-[0.2em] rounded-none flex items-center justify-center gap-2 cursor-pointer shadow-[3px_3px_0px_0px_rgba(26,26,26,1)] hover:shadow-[5px_5px_0px_0px_rgba(26,26,26,1)] hover:-translate-x-0.5 hover:-translate-y-0.5"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isLoading ? "AUTHORIZING GATEWAY..." : `AUTHORIZE & PLACE ORDER (₹${grandTotal.toLocaleString()})`}</span>
                </button>
              </div>
            </form>

            {/* Right Module: Order summary items display sheet */}
            <div className="md:w-5/12 bg-[#F9F8F6] border-t md:border-t-0 md:border-l border-[#1A1A1A] p-6 sm:p-8 flex flex-col justify-between overflow-y-auto">
              <div>
                <div className="flex justify-between items-center mb-5 pb-3 border-b border-[#1A1A1A]/10">
                  <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A]">Review Summary</span>
                  <button
                    onClick={onClose}
                    className="p-1 px-2.5 border border-[#1A1A1A] bg-white text-stone-800 hover:bg-[#1A1A1A] hover:text-white font-mono text-[9px] font-bold uppercase tracking-widest transition cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>

                <div className="space-y-4 divide-y divide-[#1A1A1A]/10 max-h-[280px] overflow-y-auto pr-1">
                  {cart.length === 0 ? (
                    <div className="py-12 text-center text-stone-400 font-mono text-xs">
                      No matching checkout items in summary cart.
                    </div>
                  ) : (
                    cart.map((item, id) => (
                      <div key={id} className="pt-3 first:pt-0 flex items-center gap-3">
                        <img
                          src={item.product.imageUrl}
                          alt={item.product.name}
                          referrerPolicy="no-referrer"
                          className="w-10 h-14 object-cover rounded-none border border-[#1A1A1A]/10 shadow-xs shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-bold text-stone-900 leading-tight block truncate uppercase font-serif">
                            {item.product.name}
                          </h4>
                          <span className="text-[9px] text-stone-500 font-mono uppercase block mt-0.5">
                            Size: <span className="text-black font-extrabold">{item.size}</span> • Qty: <span className="text-black font-extrabold">{item.quantity}</span>
                          </span>
                          <span className="text-xs font-mono font-bold text-stone-900 block mt-1">
                            ₹{item.product.price.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Totals arithmetic details sheet */}
              <div className="mt-8 border-t border-[#1A1A1A]/15 pt-5 space-y-2 font-mono text-[11px]">
                <div className="flex justify-between text-stone-500">
                  <span>Subtotal sum</span>
                  <span className="font-bold text-black">₹{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-stone-500">
                  <span>Atelier courier shipping</span>
                  <span className="font-bold text-black">{shipping === 0 ? "FREE" : `₹${shipping.toLocaleString()}`}</span>
                </div>
                <div className="flex justify-between text-stone-500">
                  <span>Aura sales tax (8%)</span>
                  <span className="font-bold text-black">₹{tax.toLocaleString()}</span>
                </div>

                <hr className="border-[#1A1A1A]/10 my-2" />

                <div className="flex justify-between text-[#1A1A1A] text-xs font-black uppercase pt-1">
                  <span>Grand Total</span>
                  <span>₹{grandTotal.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </>
        )}

      </div>
    </div>
  );
}
