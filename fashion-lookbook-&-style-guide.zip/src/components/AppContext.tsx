/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from "react";
import { User, Product, Collection, CartItem, Order } from "../types";

interface AppContextType {
  currentUser: User | null;
  products: Product[];
  lookbooks: Collection[];
  cart: CartItem[];
  wishlist: Product[];
  orders: Order[];
  isLoading: boolean;
  errorMsg: string | null;
  successMsg: string | null;
  showAuthModal: boolean;
  setShowAuthModal: (show: boolean) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  // Auth actions
  loginUser: (email: string, pass: string) => Promise<boolean>;
  registerUser: (name: string, email: string, pass: string) => Promise<boolean>;
  logoutUser: () => void;
  // Product actions
  fetchProducts: () => Promise<void>;
  createProduct: (pData: Partial<Product>) => Promise<boolean>;
  editProduct: (id: string, pData: Partial<Product>) => Promise<boolean>;
  removeProduct: (id: string) => Promise<boolean>;
  // Collection actions
  fetchLookbooks: () => Promise<void>;
  createLookbook: (cData: Partial<Collection>) => Promise<boolean>;
  editLookbook: (id: string, cData: Partial<Collection>) => Promise<boolean>;
  removeLookbook: (id: string) => Promise<boolean>;
  // Cart Actions
  addToCart: (product: Product, size: string, quantity?: number) => void;
  removeFromCart: (productId: string, size: string) => void;
  updateCartQuantity: (productId: string, size: string, qty: number) => void;
  clearCart: () => void;
  // Wishlist Actions
  toggleWishlist: (product: Product) => void;
  isProductInWishlist: (productId: string) => boolean;
  // Checkout Order Actions
  placeOrder: (address: any, payment: any) => Promise<any>;
  setAlert: (msg: string, type: 'success' | 'error') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [lookbooks, setLookbooks] = useState<Collection[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Theme states
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem("aura_dark_mode") === "true";
  });

  const toggleDarkMode = () => {
    setIsDarkMode(prev => {
      const next = !prev;
      localStorage.setItem("aura_dark_mode", String(next));
      return next;
    });
  };

  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
  }, [isDarkMode]);

  // Load local state for Cart & Wishlist & Session on startup
  useEffect(() => {
    const savedCart = localStorage.getItem("aura_cart");
    if (savedCart) {
      try { setCart(JSON.parse(savedCart)); } catch (e) {}
    }

    const savedWishlist = localStorage.getItem("aura_wishlist");
    if (savedWishlist) {
      try { setWishlist(JSON.parse(savedWishlist)); } catch (e) {}
    }

    const savedUser = localStorage.getItem("aura_user");
    if (savedUser) {
      try { setCurrentUser(JSON.parse(savedUser)); } catch (e) {}
    }

    // Call fetch on APIs
    refreshData();
  }, []);

  // Save Cart to LocalStorage on edit
  useEffect(() => {
    localStorage.setItem("aura_cart", JSON.stringify(cart));
  }, [cart]);

  // Save Wishlist to LocalStorage on edit
  useEffect(() => {
    localStorage.setItem("aura_wishlist", JSON.stringify(wishlist));
  }, [wishlist]);

  const setAlert = (msg: string, type: 'success' | 'error') => {
    if (type === 'success') {
      setSuccessMsg(msg);
      setTimeout(() => setSuccessMsg(null), 4000);
    } else {
      setErrorMsg(msg);
      setTimeout(() => setErrorMsg(null), 4000);
    }
  };

  const refreshData = async () => {
    setIsLoading(true);
    await Promise.all([fetchProducts(), fetchLookbooks()]);
    setIsLoading(false);
  };

  const fetchProducts = async () => {
    try {
      const res = await fetch("/api/products");
      if (res.ok) {
        const data = await res.json();
        setProducts(data);
      }
    } catch (e) {
      console.error("Failed to fetch products API, keeping client in sync.", e);
    }
  };

  const fetchLookbooks = async () => {
    try {
      const res = await fetch("/api/lookbooks");
      if (res.ok) {
        const data = await res.json();
        setLookbooks(data);
      }
    } catch (e) {
      console.error("Failed to fetch lookbooks API.", e);
    }
  };

  // AUTH ACTIONS
  const loginUser = async (email: string, pass: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password: pass })
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
        localStorage.setItem("aura_user", JSON.stringify(data.user));
        setAlert(`Welcome back, ${data.user.name}!`, 'success');
        setIsLoading(false);
        return true;
      } else {
        const err = await res.json();
        setAlert(err.error || "Login credentials unauthorized.", 'error');
      }
    } catch (e) {
      setAlert("Server connection failed.", 'error');
    }
    setIsLoading(false);
    return false;
  };

  const registerUser = async (name: string, email: string, pass: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password: pass })
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
        localStorage.setItem("aura_user", JSON.stringify(data.user));
        setAlert(`Account successfully registered, welcome ${data.user.name}!`, 'success');
        setIsLoading(false);
        return true;
      } else {
        const err = await res.json();
        setAlert(err.error || "Registration validation failed.", 'error');
      }
    } catch (e) {
      setAlert("Server connection failed.", 'error');
    }
    setIsLoading(false);
    return false;
  };

  const logoutUser = () => {
    setCurrentUser(null);
    localStorage.removeItem("aura_user");
    setAlert("You have logged out.", 'success');
  };

  // PRODUCT ACTIONS
  const createProduct = async (pData: Partial<Product>): Promise<boolean> => {
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(pData)
      });
      if (res.ok) {
        await fetchProducts();
        setAlert("Product added to looking catalog successfully.", "success");
        return true;
      } else {
        const err = await res.json();
        setAlert(err.error || "Failed to add product.", 'error');
      }
    } catch (e) {
      setAlert("Network failed to dispatch product creation.", 'error');
    }
    return false;
  };

  const editProduct = async (id: string, pData: Partial<Product>): Promise<boolean> => {
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(pData)
      });
      if (res.ok) {
        await fetchProducts();
        setAlert("Product details saved successfully.", "success");
        return true;
      }
    } catch (e) {
      setAlert("Network failed to dispatch product update.", 'error');
    }
    return false;
  };

  const removeProduct = async (id: string): Promise<boolean> => {
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        await fetchProducts();
        setAlert("Product removed from looking catalog.", "success");
        return true;
      }
    } catch (e) {
      setAlert("Network failed to dispatch product deletion.", 'error');
    }
    return false;
  };

  // LOOKBOOKS (COLLECTIONS) ACTIONS
  const createLookbook = async (cData: Partial<Collection>): Promise<boolean> => {
    try {
      const res = await fetch("/api/lookbooks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(cData)
      });
      if (res.ok) {
        await fetchLookbooks();
        setAlert("Created custom fashion collection lookbook.", "success");
        return true;
      }
    } catch (e) {
      setAlert("Network failed to dispatch lookbook creation.", 'error');
    }
    return false;
  };

  const editLookbook = async (id: string, cData: Partial<Collection>): Promise<boolean> => {
    try {
      const res = await fetch(`/api/lookbooks/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(cData)
      });
      if (res.ok) {
        await fetchLookbooks();
        setAlert("Lookbook details updated.", "success");
        return true;
      }
    } catch (e) {
      setAlert("Network failed to edit lookbook details.", 'error');
    }
    return false;
  };

  const removeLookbook = async (id: string): Promise<boolean> => {
    try {
      const res = await fetch(`/api/lookbooks/${id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        await fetchLookbooks();
        setAlert("Lookbook collection deleted.", "success");
        return true;
      }
    } catch (e) {
      setAlert("Network failed to delete lookbook.", 'error');
    }
    return false;
  };

  // CART & WISHLIST ACTIONS
  const addToCart = (product: Product, size: string, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id && item.size === size);
      if (existing) {
        return prev.map(item => 
          item.product.id === product.id && item.size === size
            ? { ...item, quantity: Math.min(product.inventory, item.quantity + quantity) }
            : item
        );
      }
      return [...prev, { product, size, quantity }];
    });
    setAlert(`${product.name} (${size}) added to checkout Cart!`, 'success');
  };

  const removeFromCart = (productId: string, size: string) => {
    setCart(prev => prev.filter(item => !(item.product.id === productId && item.size === size)));
    setAlert("Item removed from Cart.", 'success');
  };

  const updateCartQuantity = (productId: string, size: string, qty: number) => {
    setCart(prev => prev.map(item => 
      item.product.id === productId && item.size === size
        ? { ...item, quantity: Math.max(1, qty) }
        : item
    ));
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (product: Product) => {
    const isSaved = wishlist.some(item => item.id === product.id);
    if (isSaved) {
      setWishlist(prev => prev.filter(item => item.id !== product.id));
      setAlert("Removed styling piece from saved Wishlist.", 'success');
    } else {
      setWishlist(prev => [...prev, product]);
      setAlert("Styling piece saved to favorite Wishlist!", 'success');
    }
  };

  const isProductInWishlist = (productId: string) => {
    return wishlist.some(item => item.id === productId);
  };

  // ORDER PLACEMENT
  const placeOrder = async (address: any, payment: any): Promise<any> => {
    setIsLoading(true);
    const subtotal = cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
    const shipping = subtotal > 150 ? 0 : 15;
    const tax = Math.round(subtotal * 0.08 * 100) / 100;
    const total = subtotal + shipping + tax;

    const payload = {
      userId: currentUser?.id || "guest",
      buyerName: currentUser?.name || "Guest User",
      email: currentUser?.email || "guest@style.com",
      items: cart,
      subtotal,
      shipping,
      tax,
      total,
      address,
      payment
    };

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        const orderData = await res.json();
        setOrders(prev => [orderData, ...prev]);
        clearCart();
        setIsLoading(false);
        setAlert("Order verified & compilation processed successfully!", 'success');
        return orderData;
      } else {
        const err = await res.json();
        setAlert(err.error || "Checkout formulation error.", 'error');
      }
    } catch (e) {
      // Offline local bypass
      const localOrderObj = {
        id: "local_ord_" + Math.random().toString(36).substr(2, 9),
        ...payload,
        status: "processing" as const,
        date: new Date().toISOString()
      };
      setOrders(prev => [localOrderObj, ...prev]);
      clearCart();
      setIsLoading(false);
      setAlert("Checkout saved locally.", 'success');
      return localOrderObj;
    }
    setIsLoading(false);
    return null;
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      products,
      lookbooks,
      cart,
      wishlist,
      orders,
      isLoading,
      errorMsg,
      successMsg,
      showAuthModal,
      setShowAuthModal,
      loginUser,
      registerUser,
      logoutUser,
      fetchProducts,
      createProduct,
      editProduct,
      removeProduct,
      fetchLookbooks,
      createLookbook,
      editLookbook,
      removeLookbook,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      clearCart,
      toggleWishlist,
      isProductInWishlist,
      placeOrder,
      setAlert,
      isDarkMode,
      toggleDarkMode
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used inside an AppProvider context hierarchy.");
  }
  return context;
}
