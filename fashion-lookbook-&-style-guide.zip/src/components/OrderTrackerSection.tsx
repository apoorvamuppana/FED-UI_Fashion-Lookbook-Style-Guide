/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { useApp } from "./AppContext";
import { Search, Compass, Truck, CheckCircle2, Clock, MapPin, ClipboardList, Box, Sparkles, ChevronRight, Package, ShieldCheck } from "lucide-react";

export default function OrderTrackerSection() {
  const { orders } = useApp();
  const [searchId, setSearchId] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [trackingMsg, setTrackingMsg] = useState<string | null>(null);

  // Default seeded pre-loaded demo orders to make the portal immediately functional and premium!
  const demoOrders = [
    {
      id: "ord_fashion_demo_1",
      buyerName: "PODDUTURI KARTHEEK REDDY",
      email: "kartheek@style.com",
      date: new Date(Date.now() - 36 * 60 * 60 * 1000).toISOString(), // 36 hours ago
      items: [
        {
          product: { name: "Classic Double-Breasted Trench Coat", price: 8999, category: "Outerwear" },
          quantity: 1,
          size: "L"
        },
        {
          product: { name: "Classic Sand Suede Chelsea Boots", price: 7999, category: "Footwear" },
          quantity: 1,
          size: "UK-9"
        }
      ],
      subtotal: 16998,
      shipping: 0,
      tax: 1359.84,
      total: 18357.84,
      address: {
        fullName: "Kartheek Reddy",
        street: "B-402, Vogue Signature Tower, Bandra West",
        city: "Mumbai",
        state: "Maharashtra",
        zipCode: "400050",
        country: "India"
      },
      payment: { method: "card", cardLast4: "5833" },
      status: "shipped", // processing, shipped, delivered, pending
    },
    {
      id: "ord_fashion_demo_2",
      buyerName: "MUPPANA CHINMAYA APOORVA",
      email: "apoorva@style.com",
      date: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(), // 12 hours ago
      items: [
        {
          product: { name: "V-Neck Pleated Emerald Silk Dress", price: 12499, category: "Dresses" },
          quantity: 1,
          size: "S"
        }
      ],
      subtotal: 12499,
      shipping: 0,
      tax: 999.92,
      total: 13498.92,
      address: {
        fullName: "Muppana Chinmaya Apoorva",
        street: "Flats 12A, Orchid Estate, Vogue Center",
        city: "Delhi",
        state: "Delhi NCR",
        zipCode: "110001",
        country: "India"
      },
      payment: { method: "upi" },
      status: "processing",
    },
    {
      id: "ord_fashion_demo_3",
      buyerName: "Fashion Enthusiast",
      email: "guest@style.com",
      date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), // 5 days ago
      items: [
        {
          product: { name: "Oversized Utility Heavyweight Hoodie", price: 4499, category: "Streetwear" },
          quantity: 1,
          size: "XL"
        }
      ],
      subtotal: 4499,
      shipping: 150,
      tax: 359.92,
      total: 5008.92,
      address: {
        fullName: "Rahul Sharma",
        street: "House 9, Elite Avenue, Jubilee Hills",
        city: "Hyderabad",
        state: "Telangana",
        zipCode: "500033",
        country: "India"
      },
      payment: { method: "paypal" },
      status: "delivered",
    }
  ];

  // Merge local user-placed orders and default high-fashion demo orders
  const allOrdersList = [...orders, ...demoOrders];

  useEffect(() => {
    // Default select first demo order so some visuals display immediately
    if (allOrdersList.length > 0 && !selectedOrder) {
      setSelectedOrder(allOrdersList[0]);
    }
  }, [orders]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) return;

    const code = searchId.trim().toUpperCase();
    const found = allOrdersList.find(
      o => o.id.toUpperCase() === code || o.id.toUpperCase().includes(code)
    );

    if (found) {
      setSelectedOrder(found);
      setTrackingMsg(null);
    } else {
      setTrackingMsg(`Order ID "${searchId}" not spotted in active transit logs. Please try choosing a shortcut demo order below.`);
    }
  };

  const selectPreseed = (order: any) => {
    setSelectedOrder(order);
    setSearchId(order.id);
    setTrackingMsg(null);
  };

  // Stepper milestones builder
  const getMilestones = (status: string, dateStr: string) => {
    const baseDate = new Date(dateStr);
    
    const fmt = (hoursOffset: number) => {
      const d = new Date(baseDate.getTime() + hoursOffset * 60 * 60 * 1000);
      return d.toLocaleDateString("en-IN", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });
    };

    return [
      {
        title: "Order Placed & Registered",
        desc: "Secure credit checking and structural validation complete.",
        date: fmt(0),
        status: "completed"
      },
      {
        title: "Aesthetic Design & Quality Control",
        desc: "Stitching review and drape checks certifying impeccable tailoring standards by chief stylist.",
        date: fmt(3),
        status: status === "pending" ? "pending" : "completed"
      },
      {
        title: "Dispatched to Premium Logistics Hub",
        desc: "Secured in custom weather-proof black box packaging. Airway Bill generated.",
        date: fmt(8),
        status: ["pending", "processing"].includes(status) ? "pending" : "completed"
      },
      {
        title: "In Transit at Regional Sorting Facility",
        desc: "Processed through national express hub closest to delivery district.",
        date: fmt(15),
        status: ["pending", "processing"].includes(status) ? "pending" : (status === "shipped" ? "current" : "completed")
      },
      {
        title: "Out for Executive Delivery",
        desc: "Assigned to dedicated local courier agent carrying secure verification prompts.",
        date: fmt(24),
        status: ["pending", "processing", "shipped"].includes(status) ? "pending" : "completed"
      },
      {
        title: "Delivered & Hand-Signed Showcase",
        desc: "Coutura box received in pristine shape. Signatures archived successfully.",
        date: fmt(25),
        status: status === "delivered" ? "completed" : "pending"
      }
    ];
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-300 border-green-300 dark:border-green-800 font-extrabold";
      case "shipped":
        return "bg-blue-100 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 border-blue-300 dark:border-blue-800 font-extrabold";
      case "processing":
        return "bg-amber-105 bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-300 dark:border-amber-800 font-extrabold";
      default:
        return "bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-300 border-orange-300 dark:border-orange-850 font-extrabold";
    }
  };

  return (
    <div id="order-tracker-portal" className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Editorial Header */}
      <div className="border-b border-[#1A1A1A]/10 pb-8 mb-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-5">
        <div>
          <span className="font-mono text-[9px] tracking-[0.25em] text-[#C4A484] font-bold block mb-1.5 uppercase">REAL-TIME TRANSIT HUB</span>
          <h1 className="font-serif text-3xl sm:text-4xl font-black tracking-tighter text-[#1A1A1A] uppercase">
            Order tracking & status
          </h1>
          <p className="font-mono text-[9px] uppercase tracking-wider text-stone-500 mt-2 leading-relaxed">
            Monitor stitching QC checkpoints, courier handovers, and physical delivery coordinates.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Left Side: Search Input & Shortcuts selection */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Tracking Search Form */}
          <div className="bg-white border border-[#1A1A1A] p-6 rounded-none shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            <h3 className="font-mono text-xs uppercase tracking-wider font-extrabold text-[#1A1A1A] mb-4">
              Aura Cargo Locator
            </h3>
            
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="flex gap-2.5">
                <input
                  type="text"
                  value={searchId}
                  onChange={(e) => setSearchId(e.target.value)}
                  placeholder="E.g. ord_fashion_demo_1"
                  className="w-full bg-white border border-[#1A1A1A] rounded-none px-3.5 py-3 text-xs font-mono font-bold focus:bg-[#F9F8F6] focus:outline-none placeholder-stone-400"
                />
                <button
                  type="submit"
                  className="px-5 bg-[#1A1A1A] text-white hover:bg-[#C4A484] hover:text-black border border-[#1A1A1A] transition rounded-none flex items-center justify-center cursor-pointer"
                >
                  <Search className="w-4 h-4" />
                </button>
              </div>

              {trackingMsg && (
                <p className="font-mono text-[10px] text-red-600 leading-normal uppercase">
                  {trackingMsg}
                </p>
              )}
            </form>
          </div>

          {/* Quick Active demo list to choose from */}
          <div className="bg-white border border-[#1A1A1A]/20 p-5 rounded-none space-y-4">
            <div>
              <span className="font-mono text-[9px] font-bold text-[#C4A484] uppercase tracking-widest block mb-1">Interactive shortcuts</span>
              <h4 className="font-serif text-sm font-black uppercase text-[#1A1A1A]">Registered Order Catalog</h4>
            </div>

            <div className="divide-y divide-[#1A1A1A]/10 max-h-[240px] overflow-y-auto">
              {allOrdersList.map((order) => (
                <button
                  key={order.id}
                  onClick={() => selectPreseed(order)}
                  className={`w-full py-3 px-2 flex justify-between items-center text-left hover:bg-[#F9F8F6]/85 transition rounded-none border-b border-transparent ${selectedOrder?.id === order.id ? 'bg-[#F9F8F6] border-l-4 border-l-[#C4A484]' : ''}`}
                >
                  <div className="min-w-0 pr-2">
                    <span className="font-mono text-[9px] font-extrabold text-[#1A1A1A] block">
                      #{order.id}
                    </span>
                    <span className="font-sans text-[11px] text-stone-550 block truncate">
                      {order.buyerName} ({order.address.city})
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0 font-mono text-[8px] uppercase tracking-wider font-extrabold">
                    <span className={`px-2 py-0.5 border ${getStatusBadgeClass(order.status)}`}>
                      {order.status}
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-stone-400" />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* High-fashion logistics seal */}
          <div className="border border-[#1A1A1A] p-5 rounded-none bg-[#1A1A1A] text-white shadow-[4px_4px_0px_0px_rgba(196,164,132,1)]">
            <div className="flex items-center gap-2 text-xs font-mono text-[#C4A484] uppercase tracking-widest mb-2 font-bold">
              <Compass className="w-4 h-4 animate-spin-slow" />
              <span>Aura Shipping Pledge</span>
            </div>
            <p className="font-sans text-xs text-stone-300 leading-relaxed font-light">
               Every premium fashion garment is packed individually in customized luxury boxes lined with bespoke visual lining sheets. Stitching, seam strength, and button closures checked and validated directly at our Delhi Vogue Atelier.
            </p>
          </div>

        </div>

        {/* Right Side: Active tracking detail with timeline steps */}
        <div className="lg:col-span-7">
          {selectedOrder ? (
            <div className="bg-white border border-[#1A1A1A] overflow-hidden shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
              
              {/* Top Banner details */}
              <div className="p-6 border-b border-[#1A1A1A] bg-[#F9F8F6] flex flex-wrap justify-between items-end gap-3">
                <div>
                  <div className="flex items-center gap-2.5 mb-1.5">
                    <span className="font-mono text-xs font-black uppercase text-[#1A1A1A]">ORDER REFERENCE SHEET</span>
                    <span className={`text-[8.5px] font-mono px-2 py-0.5 border uppercase font-extrabold ${getStatusBadgeClass(selectedOrder.status)}`}>
                      {selectedOrder.status}
                    </span>
                  </div>
                  <h3 className="font-mono text-base font-extrabold text-black uppercase">
                    ID: {selectedOrder.id}
                  </h3>
                  <p className="font-mono text-[9px] text-stone-450 uppercase font-bold mt-1">
                    Booked On: {new Date(selectedOrder.date).toLocaleDateString("en-IN", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-mono uppercase text-stone-400 block mb-0.5 font-bold">Total Dispatched</span>
                  <span className="font-mono text-xl font-black text-[#1A1A1A]">₹{selectedOrder.total?.toLocaleString()}</span>
                </div>
              </div>

              {/* Garments Pack Details */}
              <div className="p-6 border-b border-[#1A1A1A]/10 space-y-3 bg-stone-50/50">
                <div className="flex items-center gap-1.5 text-[9px] font-mono font-black text-[#C4A484] uppercase tracking-widest">
                  <Box className="w-4 h-4" />
                  <span>Couture Transit Manifesto ({selectedOrder.items.length} items)</span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selectedOrder.items.map((item: any, idx: number) => (
                    <div key={idx} className="bg-white p-3 border border-stone-200 flex justify-between items-center rounded-none font-mono text-[10px]">
                      <div className="min-w-0 pr-2">
                        <span className="block font-bold text-[#1A1A1A] uppercase truncate text-[11px]">{item.product.name}</span>
                        <span className="block text-[8.5px] text-[#C4A484] uppercase font-bold mt-0.5">Size {item.size} • Qty {item.quantity}</span>
                      </div>
                      <span className="font-black text-black shrink-0">₹{item.product.price?.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Multi-step Shipping Timeline tracker */}
              <div className="p-6 sm:p-8 space-y-6">
                <div className="flex items-center gap-1.5 text-[10px] font-mono font-black text-stone-400 uppercase tracking-widest pb-2 border-b border-stone-100">
                  <Truck className="w-4 h-4 text-black" />
                  <span>Transit Milestone Stepper status logs</span>
                </div>

                <div className="relative pl-6 space-y-6">
                  {/* Vertical line indicator */}
                  <div className="absolute left-[7px] top-2 bottom-2 w-0.5 bg-[#1A1A1A]/15 border-dashed border-l" />

                  {getMilestones(selectedOrder.status, selectedOrder.date).map((step, milestoneIdx) => {
                    const isCompleted = step.status === "completed";
                    const isCurrent = step.status === "current";

                    return (
                      <div key={milestoneIdx} className="relative group">
                        
                        {/* Milestone dot badge */}
                        <div className={`absolute -left-[25px] top-0.5 w-3.5 h-3.5 border rounded-none transition duration-200 flex items-center justify-center ${
                          isCompleted
                            ? "bg-[#1A1A1A] border-[#1A1A1A] text-white"
                            : isCurrent
                            ? "bg-[#C4A484] border-[#1A1A1A] animate-pulse scale-110"
                            : "bg-white border-stone-300"
                        }`}>
                          {isCompleted && <div className="w-1.5 h-1.5 bg-white" />}
                          {isCurrent && <div className="w-1.5 h-1.5 bg-black" />}
                        </div>

                        {/* Text and context layout */}
                        <div className="flex flex-col sm:flex-row justify-between items-start gap-1 sm:gap-4 ml-2">
                          <div>
                            <h4 className={`text-xs uppercase font-extrabold tracking-tight ${isCompleted ? 'text-[#1A1A1A] font-black' : isCurrent ? 'text-[#C4A484]' : 'text-stone-400'}`}>
                              {step.title}
                            </h4>
                            <p className="text-[11px] text-stone-500 mt-1 max-w-md leading-relaxed">
                              {step.desc}
                            </p>
                          </div>
                          
                          {/* Simulated timing */}
                          {isCompleted && (
                            <span className="font-mono text-[9px] text-[#C4A484] uppercase whitespace-nowrap bg-[#F9F8F6] px-2 py-0.5 font-bold shrink-0">
                              {step.date}
                            </span>
                          )}
                        </div>

                      </div>
                    );
                  })}
                </div>

              </div>

              {/* Delivery Destination coordinates details */}
              <div className="p-6 border-t border-[#1A1A1A]/10 bg-[#F9F8F6]/30 flex flex-col sm:flex-row justify-between gap-4 font-mono text-[10px] text-stone-500">
                <div>
                  <span className="block text-[8px] uppercase font-bold text-stone-400 tracking-wider mb-1">CONSIGNEE DETAILS</span>
                  <span className="block text-[#1A1A1A] font-extrabold uppercase text-[11px]">{selectedOrder.buyerName}</span>
                  <span className="block text-stone-600 mt-0.5">{selectedOrder.address.street}</span>
                  <span className="block text-stone-600 font-bold uppercase">{selectedOrder.address.city}, {selectedOrder.address.state} • {selectedOrder.address.zipCode}</span>
                </div>
                
                <div className="sm:text-right">
                  <span className="block text-[8px] uppercase font-bold text-stone-400 tracking-wider mb-1">STATION CARRIER CONTROL</span>
                  <span className="block text-[#1A1A1A] font-bold">AURA ROYAL LOGISTICS (DELHI)</span>
                  <span className="block text-[#1A1A1A] font-mono mt-0.5">TRACKING: <span className="underline select-all uppercase">IN_AWB_{selectedOrder.id.substring(4, 9)}</span></span>
                </div>
              </div>

            </div>
          ) : (
            <div className="py-24 text-center border-2 border-dashed border-stone-300 rounded-none bg-white font-mono text-xs text-stone-400">
              <Compass className="w-10 h-10 text-stone-300 mx-auto mb-4 animate-spin-slow" />
              Please select a transit order on the left coordinate logs to view progress statistics.
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
