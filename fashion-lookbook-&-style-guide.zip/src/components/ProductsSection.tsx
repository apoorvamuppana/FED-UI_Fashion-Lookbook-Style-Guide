/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { useApp } from "./AppContext";
import { Product } from "../types";
import { Search, Heart, ShoppingBag, Eye } from "lucide-react";

export default function ProductsSection() {
  const { products, addToCart, toggleWishlist, isProductInWishlist } = useApp();
  
  // Search state
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [activeOccasion, setActiveOccasion] = useState("All");
  const [selectedSize, setSelectedSize] = useState<Record<string, string>>({}); // id -> size
  const [selectedProductDetail, setSelectedProductDetail] = useState<Product | null>(null);

  const categories = ["All", "Outerwear", "Dresses", "Streetwear", "Footwear", "Shirts", "Pants", "Accessories"];
  const occasions = ["All", "casual", "formal", "evening", "street", "resort"];

  const handleSizeChange = (id: string, size: string) => {
    setSelectedSize(prev => ({ ...prev, [id]: size }));
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                          p.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = activeCategory === "All" || p.category === activeCategory;
    const matchesOccasion = activeOccasion === "All" || p.occasion === activeOccasion;
    return matchesSearch && matchesCategory && matchesOccasion;
  });

  return (
    <div id="catalog-module-view" className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Filters & Header Layout Grid */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12 border-b border-[#1A1A1A] pb-8">
        <div>
          <span className="font-serif text-sm italic text-[#C4A484] tracking-widest block font-bold">Atelier Ready Wear</span>
          <h2 className="font-serif text-4xl tracking-tighter text-[#1A1A1A] font-black uppercase">Garments Collection</h2>
        </div>

        {/* Search & Dynamic inputs with crisp block shadow */}
        <div className="relative w-full md:w-80">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-500">
            <Search className="w-4 h-4" />
          </span>
          <input
            id="catalog-search"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search wool-knits, trench..."
            className="w-full bg-white border border-[#1A1A1A] rounded-none pl-10 pr-4 py-3 text-xs font-mono uppercase font-bold focus:outline-none placeholder-stone-400 focus:bg-[#F9F8F6]"
          />
        </div>
      </div>

      {/* Categories Horizontal Scrolling selectors with bold grid theme */}
      <div className="border border-[#1A1A1A] p-6 mb-10 flex flex-col gap-6 bg-white shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
        {/* Category triggers */}
        <div>
          <span className="block text-[10px] font-mono uppercase tracking-[0.25em] text-[#1A1A1A] font-bold mb-3">
            Garment Category Filter
          </span>
          <div className="flex gap-2.5 overflow-x-auto pb-1.5 scrollbar-none">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setActiveCategory(c)}
                className={`py-2 px-4 rounded-none text-[11px] font-mono uppercase tracking-wider transition border cursor-pointer ${activeCategory === c ? 'bg-[#1A1A1A] text-white border-[#1A1A1A] font-bold' : 'bg-white text-stone-600 border-[#1A1A1A]/20 hover:border-[#1A1A1A] hover:text-[#1A1A1A]'}`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Occasion triggers */}
        <div>
          <span className="block text-[10px] font-mono uppercase tracking-[0.25em] text-[#C4A484] font-bold mb-3">
            Filtering By Occasion Outfit Vibe
          </span>
          <div className="flex gap-2.5 overflow-x-auto pb-1.5 scrollbar-none">
            {occasions.map((o) => (
              <button
                key={o}
                onClick={() => setActiveOccasion(o)}
                className={`py-2 px-4 rounded-none text-[11px] font-mono uppercase tracking-wider transition border cursor-pointer ${activeOccasion === o ? 'bg-[#C4A484] text-white border-[#C4A484]' : 'bg-white text-stone-500 border-stone-200 hover:border-[#1A1A1A] hover:text-[#1A1A1A]'}`}
              >
                {o === "All" ? "All Occasions" : o}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Products Display Grid Output */}
      {filteredProducts.length === 0 ? (
        <div className="py-24 text-center text-stone-500 font-mono text-xs border border-[#1A1A1A] bg-white rounded-none p-12 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
          No matching garments found in current search params. Adjust filters above.
        </div>
      ) : (
        <div id="catalog-products-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
          {filteredProducts.map((p) => {
            const currentSize = selectedSize[p.id] || "M";
            return (
              <div
                key={p.id}
                className="group relative bg-white border border-[#1A1A1A] rounded-none overflow-hidden flex flex-col transition-all duration-300 shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] hover:shadow-[8px_8px_0px_0px_rgba(26,26,26,1)] hover:-translate-x-1 hover:-translate-y-1"
              >
                
                {/* Thumb Container */}
                <div className="aspect-[3/4] overflow-hidden relative bg-stone-100 border-b border-[#1A1A1A]">
                  <img
                    src={p.imageUrl}
                    alt={p.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-700"
                  />
                  
                  {/* Heart / Wishlist trigger */}
                  <button
                    onClick={() => toggleWishlist(p)}
                    className="absolute top-4 right-4 w-9 h-9 border border-[#1A1A1A] bg-white hover:bg-[#1A1A1A] hover:text-[#C4A484] text-neutral-400 flex items-center justify-center transition cursor-pointer shadow-[2px_2px_0px_0px_rgba(26,26,26,1)]"
                    title="Save Style"
                  >
                    <Heart className={`w-4 h-4 transition ${isProductInWishlist(p.id) ? 'fill-red-500 text-red-500' : ''}`} />
                  </button>

                  {/* Inventory Warning Tags */}
                  {p.inventory === 0 ? (
                    <div className="absolute top-4 left-4 px-2 py-1 bg-stone-900 text-white text-[9px] font-mono font-bold uppercase tracking-widest border border-white">
                      Sold out
                    </div>
                  ) : p.inventory < 5 ? (
                    <div className="absolute top-4 left-4 px-2 py-1 bg-[#8B0000] text-white text-[9px] font-mono font-bold uppercase tracking-widest border border-white animate-pulse">
                      Only {p.inventory} Left
                    </div>
                  ) : null}

                  {/* Interactive details inspect overlay */}
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 w-11/12">
                    <button
                      onClick={() => setSelectedProductDetail(p)}
                      className="w-full bg-white text-black py-2.5 border border-[#1A1A1A] text-xs font-mono font-bold uppercase tracking-widest shadow-sm hover:bg-[#1A1A1A] hover:text-white transition flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                      <span>Inspect Piece</span>
                    </button>
                  </div>
                </div>

                {/* Sub Metadata description info */}
                <div className="p-5 flex-1 flex flex-col justify-between bg-white">
                  <div>
                    <div className="flex justify-between items-start leading-none mb-2">
                      <span className="text-[9px] font-mono text-[#C4A484] font-bold uppercase tracking-wider">
                        {p.category}
                      </span>
                      <span className="text-[9px] font-mono text-stone-400 capitalize font-medium italic">
                        {p.season}
                      </span>
                    </div>

                    <h4 className="font-serif text-sm font-black text-[#1A1A1A] leading-tight block truncate group-hover:text-[#C4A484] transition uppercase">
                      {p.name}
                    </h4>
                    
                    <p className="font-sans text-[11px] text-stone-500 mt-1 lines-clamp-2 leading-relaxed">
                      {p.description}
                    </p>
                  </div>

                  {/* Sizing selection & Bag Actions */}
                  <div className="mt-5 pt-4 border-t border-[#1A1A1A]/10 flex items-center justify-between">
                    <div>
                      <span className="font-mono text-md font-black text-[#1a1a1a]">
                        ₹{p.price.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      {/* Sizing dropdown selectors */}
                      {p.inventory > 0 && (
                        <select
                          value={currentSize}
                          onChange={(e) => handleSizeChange(p.id, e.target.value)}
                          className="bg-white border border-[#1A1A1A] rounded-none px-2 py-1.5 text-[10px] uppercase tracking-wider font-mono font-bold focus:outline-none cursor-pointer"
                        >
                          <option>S</option>
                          <option>M</option>
                          <option>L</option>
                          <option>XL</option>
                        </select>
                      )}

                      {/* Add directly to bag */}
                      <button
                        onClick={() => addToCart(p, currentSize, 1)}
                        disabled={p.inventory === 0}
                        className={`p-2.5 border border-[#1A1A1A] rounded-none flex items-center justify-center transition cursor-pointer ${p.inventory === 0 ? 'bg-stone-100 text-stone-450 cursor-not-allowed' : 'bg-[#1A1A1A] text-white hover:bg-[#C4A484] hover:text-black'}`}
                        title="Add to Bag"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>

                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Garment Inspection Overlays Detail Modal */}
      {selectedProductDetail && (
        <div id="detail-modal-back" className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/70 backdrop-blur-sm p-4">
          <div className="bg-[#F9F8F6] rounded-none w-full max-w-2xl border-2 border-[#1A1A1A] overflow-hidden flex flex-col sm:flex-row max-h-[90vh] shadow-[10px_10px_0px_0px_rgba(26,26,26,1)]">
            
            <div className="sm:w-1/2 aspect-[3/4] sm:aspect-auto overflow-hidden bg-stone-100 shrink-0 relative border-b sm:border-b-0 sm:border-r border-[#1A1A1A]">
              <img
                src={selectedProductDetail.imageUrl}
                alt={selectedProductDetail.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <span className="absolute top-4 left-4 text-[9px] font-mono tracking-widest font-bold bg-[#1A1A1A] text-white px-2 py-1 uppercase border border-white">
                {selectedProductDetail.season} Outfit
              </span>
            </div>

            <div className="flex-1 p-6 flex flex-col justify-between overflow-y-auto">
              <div>
                <div className="flex justify-between items-start mb-6">
                  <div className="leading-none">
                    <span className="text-[10px] font-mono text-[#C4A484] uppercase tracking-widest font-bold block mb-1">
                      {selectedProductDetail.category} LINE
                    </span>
                    <h3 className="font-serif text-xl font-bold text-[#1A1A1A] uppercase italic">
                      {selectedProductDetail.name}
                    </h3>
                  </div>
                  <button
                    onClick={() => setSelectedProductDetail(null)}
                    className="px-2 py-1 border border-[#1A1A1A] bg-white text-stone-800 hover:bg-[#1A1A1A] hover:text-white font-mono text-[10px] font-bold uppercase tracking-widest transition cursor-pointer"
                  >
                    Close
                  </button>
                </div>

                <div className="space-y-4 mt-4 text-xs text-stone-600 leading-relaxed">
                  <p>{selectedProductDetail.description}</p>
                  
                  <div className="grid grid-cols-2 gap-4 bg-white p-4 border border-[#1A1A1A] text-[10px]">
                    <div>
                      <span className="text-[#C4A484] block uppercase font-bold text-[9px]">Aesthetic Accent</span>
                      <span className="text-stone-800 font-bold capitalize font-mono">{selectedProductDetail.occasion}</span>
                    </div>
                    <div>
                      <span className="text-stone-400 block uppercase font-bold text-[9px]">Database Reference</span>
                      <span className="text-stone-800 font-mono font-bold uppercase">{selectedProductDetail.id}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-8 border-t border-[#1A1A1A]/10 pt-5 space-y-4">
                <div className="flex justify-between items-baseline leading-none text-black">
                  <span className="text-xs uppercase tracking-wider text-stone-500 font-bold">Consolidated Retail</span>
                  <span className="font-mono text-2xl font-black">₹{selectedProductDetail.price.toLocaleString()}</span>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      toggleWishlist(selectedProductDetail);
                    }}
                    className={`flex-1 py-3 px-3.5 border font-mono text-[10px] uppercase tracking-wider font-bold flex items-center justify-center gap-1.5 transition cursor-pointer ${isProductInWishlist(selectedProductDetail.id) ? 'border-red-500 bg-red-50 text-red-500' : 'border-[#1A1A1A] bg-white text-[#1A1A1A] hover:bg-stone-100'}`}
                  >
                    <Heart className="w-4 h-4 fill-current" />
                    <span>Wishlist</span>
                  </button>
                  <button
                    onClick={() => {
                      addToCart(selectedProductDetail, "M", 1);
                      setSelectedProductDetail(null);
                    }}
                    disabled={selectedProductDetail.inventory === 0}
                    className="flex-1 py-3 px-4 bg-[#1A1A1A] text-white hover:bg-[#C4A484] hover:text-black transition border border-[#1A1A1A] font-mono text-[10px] uppercase tracking-wider font-bold flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>{selectedProductDetail.inventory === 0 ? "SOLD OUT" : "ADD TO BAG"}</span>
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
