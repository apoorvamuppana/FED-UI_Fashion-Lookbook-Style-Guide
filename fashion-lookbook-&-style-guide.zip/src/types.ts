/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
}

export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  price: number;
  imageUrl: string;
  occasion: string; // 'casual' | 'formal' | 'evening' | 'street' | 'resort'
  season: string;   // 'Spring' | 'Summer' | 'Autumn' | 'Winter' | 'All-Season'
  inventory: number;
}

export interface Collection {
  id: string;
  name: string;
  description: string;
  season: string;
  coverUrl: string;
  productIds: string[];
  isEditorial?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  size: string;
}

export interface Order {
  id: string;
  userId: string;
  buyerName: string;
  email: string;
  items: CartItem[];
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
  address: {
    fullName: string;
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  payment: {
    method: 'card' | 'paypal' | 'upi';
    cardLast4?: string;
  };
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  date: string;
}
