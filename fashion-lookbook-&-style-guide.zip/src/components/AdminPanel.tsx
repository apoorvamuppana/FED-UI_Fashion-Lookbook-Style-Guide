/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { useApp } from "./AppContext";
import { Plus, Edit, Trash2, FolderSync, Shield, Settings, Info } from "lucide-react";
import { Product } from "../types";

export default function AdminPanel() {
  const { products, currentUser, createProduct, editProduct, removeProduct, lookbooks } = useApp();
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Outerwear");
  const [price, setPrice] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [occasion, setOccasion] = useState("casual");
  const [season, setSeason] = useState("All-Season");
  const [inventory, setInventory] = useState("");

  if (currentUser?.role !== "admin") {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <div className="w-16 h-16 border-2 border-[#1A1A1A] text-red-600 bg-white flex items-center justify-center mx-auto mb-6 rounded-none shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
          <Shield className="w-8 h-8" />
        </div>
        <h2 className="font-serif text-2xl font-black text-[#1A1A1A] uppercase tracking-tight">Restricted Access</h2>
        <p className="font-mono text-xs text-stone-500 mt-3 max-w-sm mx-auto leading-relaxed uppercase">
          Please authorize with an Admin account (such as Kartheek or Apoorva via the Join/Login Demo Shortcuts) to view administrative product and database modules.
        </p>
      </div>
    );
  }

  const resetForm = () => {
    setName("");
    setDescription("");
    setCategory("Outerwear");
    setPrice("");
    setImageUrl("");
    setOccasion("casual");
    setSeason("All-Season");
    setInventory("");
    setEditingId(null);
  };

  const startEdit = (p: Product) => {
    setEditingId(p.id);
    setName(p.name);
    setDescription(p.description);
    setCategory(p.category);
    setPrice(p.price.toString());
    setImageUrl(p.imageUrl);
    setOccasion(p.occasion);
    setSeason(p.season);
    setInventory(p.inventory.toString());
  };

  const handleCreateOrUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !price || !imageUrl) return;

    const payload: Partial<Product> = {
      name,
      description,
      category,
      price: Number(price),
      imageUrl,
      occasion,
      season,
      inventory: Number(inventory) || 10
    };

    if (editingId) {
      const ok = await editProduct(editingId, payload);
      if (ok) resetForm();
    } else {
      const ok = await createProduct(payload);
      if (ok) resetForm();
    }
  };

  return (
    <div id="admin-module-view" className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Intro Header */}
      <div className="border-b border-[#1A1A1A]/10 pb-8 mb-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-5">
        <div>
          <span className="font-mono text-[9px] tracking-[0.25em] text-[#C4A484] font-bold block mb-1.5 uppercase">ADMINISTRATIVE PORTAL</span>
          <h1 className="font-serif text-3xl sm:text-4xl font-black tracking-tighter text-[#1A1A1A] uppercase">
            Atelier Dashboard
          </h1>
          <p className="text-stone-500 font-mono text-[9px] uppercase tracking-wider mt-2 font-bold">
            Registered Lead: <span className="text-[#1A1A1A]">Kartheek (2520090015)</span> • State Sync Active
          </p>
        </div>
        
        {/* Quick database statistics counts */}
        <div className="flex gap-4">
          <div className="bg-white px-5 py-3 border border-[#1A1A1A]/15 rounded-none text-center min-w-[110px]">
            <span className="block text-[8px] font-mono uppercase font-bold text-stone-400 tracking-wider">Total Garments</span>
            <span className="font-mono text-lg font-black text-black">{products.length}</span>
          </div>
          <div className="bg-white px-5 py-3 border border-[#1A1A1A]/15 rounded-none text-center min-w-[110px]">
            <span className="block text-[8px] font-mono uppercase font-bold text-stone-400 tracking-wider">Collections</span>
            <span className="font-mono text-lg font-black text-black">{lookbooks.length}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Section A: Add/Edit formulation */}
        <div className="lg:col-span-5 bg-white border border-[#1A1A1A] p-6 rounded-none shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-5">
          <div className="flex justify-between items-center border-b border-[#1A1A1A]/10 pb-3">
            <h3 className="font-mono text-xs uppercase tracking-wider font-extrabold text-[#1A1A1A]">
              {editingId ? "Modify Garment Details" : "Register New Garment"}
            </h3>
            {editingId && (
              <button onClick={resetForm} className="px-2 py-1 border border-red-200 text-red-650 hover:bg-red-50 font-mono text-[9px] uppercase font-bold tracking-wider cursor-pointer">
                Cancel
              </button>
            )}
          </div>

          <form onSubmit={handleCreateOrUpdate} className="space-y-4">
            <div>
              <label className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400 mb-1.5">Product Title</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="E.g. Silk Drape Halter Dress"
                className="w-full bg-white border border-[#1A1A1A] rounded-none px-3.5 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3.5">
              <div>
                <label className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400 mb-1.5">Price (USD)</label>
                <input
                  type="number"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="220"
                  className="w-full bg-white border border-[#1A1A1A] rounded-none px-3.5 py-2.5 text-xs font-mono font-bold focus:bg-[#F9F8F6] focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400 mb-1.5">Inventory Qty</label>
                <input
                  type="number"
                  value={inventory}
                  onChange={(e) => setInventory(e.target.value)}
                  placeholder="15"
                  className="w-full bg-white border border-[#1A1A1A] rounded-none px-3.5 py-2.5 text-xs font-mono font-bold focus:bg-[#F9F8F6] focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3.5">
              <div>
                <label className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400 mb-1.5">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-white border border-[#1A1A1A] rounded-none px-2 py-2.5 text-xs font-mono font-bold uppercase focus:outline-none cursor-pointer"
                >
                  <option>Outerwear</option>
                  <option>Dresses</option>
                  <option>Streetwear</option>
                  <option>Footwear</option>
                  <option>Shirts</option>
                  <option>Pants</option>
                  <option>Accessories</option>
                  <option>Knitwear</option>
                </select>
              </div>

              <div>
                <label className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400 mb-1.5">Occasion Accent</label>
                <select
                  value={occasion}
                  onChange={(e) => setOccasion(e.target.value)}
                  className="w-full bg-white border border-[#1A1A1A] rounded-none px-2 py-2.5 text-xs font-mono font-bold uppercase focus:outline-none cursor-pointer"
                >
                  <option value="casual">Casual Walk</option>
                  <option value="formal">Formal Meet</option>
                  <option value="evening">Evening Gala</option>
                  <option value="street">Street Style</option>
                  <option value="resort">Resort Travel</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400 mb-1.5">Season Tag</label>
              <select
                value={season}
                onChange={(e) => setSeason(e.target.value)}
                className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:outline-none cursor-pointer"
              >
                <option>Spring</option>
                <option>Summer</option>
                <option>Autumn</option>
                <option>Winter</option>
                <option>All-Season</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400 mb-1.5">Image URL Connection</label>
              <input
                type="text"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://images.unsplash.com/photo-..."
                className="w-full bg-white border border-[#1A1A1A] rounded-none px-3.5 py-2 text-xs font-mono focus:outline-none focus:bg-[#F9F8F6]"
                required
              />
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase tracking-widest font-bold text-stone-400 mb-1.5">Description details</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                placeholder="Detail materials, cuts, stitching..."
                className="w-full bg-white border border-[#1A1A1A] rounded-none px-3.5 py-2 text-xs font-mono focus:outline-none focus:bg-[#F9F8F6] resize-none"
              />
            </div>

            <button
              id="admin-product-submit"
              type="submit"
              className="w-full py-4 bg-[#1A1A1A] text-white hover:bg-[#C4A484] hover:text-black border border-[#1A1A1A] transition duration-200 font-mono text-[10px] uppercase font-bold tracking-[0.2em] rounded-none flex items-center justify-center gap-2 cursor-pointer shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]"
            >
              {editingId ? (
                <>
                  <FolderSync className="w-4 h-4" />
                  <span>SAVE UPDATED DETAILS</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  <span>DISPATCH TO DATABASE</span>
                </>
              )}
            </button>
          </form>

          {/* Schema structural visual blocks */}
          <div className="bg-[#1A1A1A] p-4 border border-[#1A1A1A] rounded-none text-[#F9F8F6]">
            <div className="flex items-center gap-1.5 text-[9px] font-mono font-bold text-[#C4A484] uppercase tracking-widest mb-1.5">
              <Settings className="w-3.5 h-3.5" />
              <span>Database Model Schema</span>
            </div>
            <pre className="font-mono text-[9px] text-stone-300 overflow-x-auto leading-tight">
{`const ProductSchema = new Schema({
  name: { type: String, required: true },
  price: { type: Number, required: true },
  season: { type: String, default: "Autumn" },
  inventory: { type: Number, default: 10 }
});`}
            </pre>
          </div>
        </div>

        {/* Section B: Current Products Database table list */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white border border-[#1A1A1A] rounded-none overflow-hidden shadow-[4px_4px_0px_0px_rgba(26,26,26,1)]">
            <div className="px-5 py-4 border-b border-[#1A1A1A] flex justify-between items-center bg-[#F9F8F6]">
              <h3 className="font-mono text-xs uppercase font-extrabold text-[#1A1A1A]">Collections Database Catalog</h3>
              <span className="text-[9px] font-mono bg-[#1A1A1A] text-white px-2 py-0.5 rounded-none font-bold uppercase">
                REST API: ONLINE
              </span>
            </div>

            <div className="divide-y divide-[#1A1A1A]/10 max-h-[660px] overflow-y-auto">
              {products.length === 0 ? (
                <div className="py-16 text-center text-stone-400 font-mono text-xs">
                  No products found in state database. Register some above!
                </div>
              ) : (
                products.map((p) => (
                  <div key={p.id} className="p-4 flex items-center gap-4 hover:bg-[#F9F8F6]/40 transition duration-200">
                    <img
                      src={p.imageUrl}
                      alt={p.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-20 object-cover border border-[#1A1A1A]/10 shrink-0"
                    />
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-mono text-[#C4A484] uppercase tracking-wider font-extrabold">
                          {p.category}
                        </span>
                        <span className="w-1 h-1 bg-[#1A1A1A]" />
                        <span className="text-[9px] text-stone-400 font-mono uppercase font-bold">
                          {p.season} • {p.occasion} Accent
                        </span>
                      </div>
                      
                      <h4 className="text-sm font-serif font-black text-gray-950 leading-snug truncate mt-0.5 uppercase" title={p.name}>
                        {p.name}
                      </h4>
                      
                      <p className="text-[11px] text-stone-500 line-clamp-1 mt-0.5">
                        {p.description}
                      </p>

                      <div className="flex-wrap flex items-center gap-2.5 mt-2 font-mono text-[10px]">
                        <span className="font-mono font-black text-stone-900">₹{p.price.toLocaleString()}</span>
                        <span className="text-stone-300">|</span>
                        <span className="text-stone-400">
                          ID: <span className="text-black font-extrabold uppercase">{p.id}</span>
                        </span>
                        <span className="text-stone-300">|</span>
                        <span className={`font-bold uppercase ${p.inventory < 5 ? 'text-red-600' : 'text-stone-700'}`}>
                          STOCK: {p.inventory}
                        </span>
                      </div>
                    </div>

                    {/* REST Actions */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => startEdit(p)}
                        className="p-2 border border-[#1A1A1A] bg-white text-stone-800 hover:bg-[#1A1A1A] hover:text-white transition cursor-pointer rounded-none"
                        title="Edit details"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => removeProduct(p.id)}
                        className="p-2 border border-red-200 text-stone-400 hover:border-red-600 hover:text-red-750 hover:bg-red-50 transition cursor-pointer rounded-none"
                        title="Delete garment"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>
                ))
              )}
            </div>
          </div>
          
          {/* Quick info panel */}
          <div className="bg-white border border-[#1A1A1A] p-4 rounded-none flex items-start gap-3 shadow-[4px_4px_0px_0px_rgba(196,164,132,1)]">
            <Info className="w-4 h-4 text-[#C4A484] shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-mono text-[10px] font-bold text-[#1a1a1a] uppercase tracking-widest block">Role-Based Safeguards Active</span>
              <p className="font-sans text-xs text-stone-600 leading-relaxed">
                Database manipulations (POST, PUT, DELETE) trigger state synchronization instantly. Rest assured, checkout deductions securely update garment quantities in real-time, showing Apoorva&apos;s and Kartheek&apos;s modules interactively aligned!
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
