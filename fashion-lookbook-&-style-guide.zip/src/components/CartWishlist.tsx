/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { useApp } from "./AppContext";
import { X, Trash2, Heart, ShoppingBag, ArrowRight, Minus, Plus } from "lucide-react";

export default function CartWishlist({
  isOpen,
  onClose,
  onOpenCheckout,
  activePanel = 'cart',
  setActivePanel
}: {
  isOpen: boolean;
  onClose: () => void;
  onOpenCheckout: () => void;
  activePanel: 'cart' | 'wishlist';
  setActivePanel: (panel: 'cart' | 'wishlist') => void;
}) {
  const { cart, wishlist, removeFromCart, updateCartQuantity, toggleWishlist, addToCart } = useApp();

  if (!isOpen) return null;

  const subtotal = cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  const shipping = subtotal > 3000 ? 0 : 150;
  const tax = Math.round(subtotal * 0.08 * 100) / 100;
  const grandTotal = subtotal + shipping + tax;

  return (
    <div id="cart-wishlist-sliding-overlay" className="fixed inset-0 z-50 flex justify-end bg-[#1A1A1A]/50 backdrop-blur-xs">
      {/* Click outside to close */}
      <div className="flex-1" onClick={onClose} />

      <div className="bg-white w-full max-w-md h-full flex flex-col relative border-l-2 border-[#1A1A1A] animate-slide-in">
        
        {/* Header Block Drawer Panel */}
        <div className="p-5 border-b border-[#1A1A1A] flex justify-between items-center bg-[#F9F8F6]">
          <div className="flex space-x-5">
            <button
              id={`tab-toggle-cart`}
              onClick={() => setActivePanel('cart')}
              className={`font-mono text-xs font-bold uppercase tracking-wider relative py-1 cursor-pointer ${activePanel === 'cart' ? 'text-[#1A1A1A] border-b-2 border-[#1A1A1A]' : 'text-stone-400'}`}
            >
              Couture Bag ({cart.length})
            </button>
            <button
              id={`tab-toggle-wishlist`}
              onClick={() => setActivePanel('wishlist')}
              className={`font-mono text-xs font-bold uppercase tracking-wider relative py-1 cursor-pointer ${activePanel === 'wishlist' ? 'text-[#1A1A1A] border-b-2 border-[#1A1A1A]' : 'text-stone-400'}`}
            >
              Saved Styles ({wishlist.length})
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 border border-[#1A1A1A] bg-white text-stone-800 hover:bg-[#1A1A1A] hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {activePanel === 'cart' ? (
            /* CART OPTION PANEL */
            <div className="space-y-4">
              {cart.length === 0 ? (
                <div className="py-20 text-center text-stone-400 font-mono text-xs flex flex-col items-center justify-center space-y-4">
                  <ShoppingBag className="w-10 h-10 text-stone-300" />
                  <p className="max-w-xs">Your Couture bag is empty. Explore our design collections to fill it!</p>
                </div>
              ) : (
                cart.map((item, idx) => (
                  <div
                    key={`${item.product.id}-${item.size}-${idx}`}
                    className="p-3 border border-[#1A1A1A]/15 bg-white flex gap-4 hover:border-[#1A1A1A] transition duration-200 rounded-none"
                  >
                    <img
                      src={item.product.imageUrl}
                      alt={item.product.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-20 object-cover border border-[#1A1A1A]/10 shrink-0 rounded-none"
                    />

                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start leading-none mb-1">
                          <span className="text-[9px] font-mono text-[#C4A484] uppercase font-bold tracking-wider">
                            {item.product.category}
                          </span>
                          <span className="text-[9px] border border-[#1A1A1A] text-stone-800 px-1.5 py-0.5 font-mono font-bold uppercase rounded-none">
                            Size {item.size}
                          </span>
                        </div>

                        <h4 className="text-xs font-bold text-[#1A1A1A] leading-snug truncate" title={item.product.name}>
                          {item.product.name}
                        </h4>

                        <span className="text-xs font-mono font-black text-stone-800 block mt-1">
                          ₹{item.product.price.toLocaleString()}
                        </span>
                      </div>

                      {/* Quantity & Trash actions */}
                      <div className="flex justify-between items-center mt-2.5">
                        <div className="flex items-center space-x-1.5 bg-stone-100 border border-[#1A1A1A]/20 p-0.5 rounded-none">
                          <button
                            onClick={() => updateCartQuantity(item.product.id, item.size, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                            className="p-1 rounded-none text-stone-500 hover:text-black hover:bg-white transition disabled:opacity-50 cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="font-mono text-xs font-bold px-2 w-6 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateCartQuantity(item.product.id, item.size, item.quantity + 1)}
                            disabled={item.quantity >= item.product.inventory}
                            className="p-1 rounded-none text-stone-500 hover:text-black hover:bg-white transition disabled:opacity-50 cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => removeFromCart(item.product.id, item.size)}
                          className="p-1 text-stone-400 hover:text-red-600 transition cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          ) : (
            /* WISHLIST OPTION PANEL */
            <div className="space-y-4">
              {wishlist.length === 0 ? (
                <div className="py-20 text-center text-stone-400 font-mono text-xs flex flex-col items-center justify-center space-y-4">
                  <Heart className="w-10 h-10 text-stone-300" />
                  <p className="max-w-xs">Your saved styles folder is empty. Heart items in our gallery collections!</p>
                </div>
              ) : (
                wishlist.map((p) => (
                  <div
                    key={p.id}
                    className="p-3 border border-[#1A1A1A]/15 bg-white flex items-center justify-between gap-4 rounded-none hover:border-[#1A1A1A] transition duration-200"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={p.imageUrl}
                        alt={p.name}
                        referrerPolicy="no-referrer"
                        className="w-12 h-16 object-cover border border-[#1A1A1A]/10 shrink-0 rounded-none"
                      />
                      <div className="min-w-0 leading-none">
                        <span className="text-[9px] font-mono text-[#C4A484] uppercase font-bold block mb-1">
                          {p.category}
                        </span>
                        <h4 className="text-xs font-bold text-stone-900 leading-snug truncate">
                          {p.name}
                        </h4>
                        <span className="text-xs font-mono font-bold text-stone-800 block mt-1.5">
                          ₹{p.price.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Move to bag / removal actions */}
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => {
                          addToCart(p, "M", 1);
                          toggleWishlist(p);
                        }}
                        disabled={p.inventory === 0}
                        className="p-2 border border-[#1A1A1A] bg-[#1A1A1A] text-white hover:bg-white hover:text-black text-xs uppercase font-bold transition disabled:opacity-50 cursor-pointer rounded-none"
                        title="Move to Checkout Bag"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => toggleWishlist(p)}
                        className="p-2 border border-red-200 text-stone-400 hover:text-red-650 hover:bg-red-50 transition cursor-pointer rounded-none"
                        title="Delete Wishlist Outfit"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Footer Billing Breakdown Calculations */}
        {activePanel === 'cart' && cart.length > 0 && (
          <div className="p-5 border-t border-[#1A1A1A] bg-[#F9F8F6] shrink-0 space-y-4 font-mono text-[11px]">
            <div className="space-y-1.5">
              <div className="flex justify-between text-stone-500">
                <span>Subtotal Items</span>
                <span className="font-bold text-black">₹{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-stone-500">
                <span>Transitional Courier Shipping</span>
                <span className="font-bold text-black">{shipping === 0 ? "FREE" : `₹${shipping.toLocaleString()}`}</span>
              </div>
              <div className="flex justify-between text-stone-500">
                <span>Aura Sales Tax (8%)</span>
                <span className="font-bold text-black">₹{tax.toLocaleString()}</span>
              </div>
              
              <hr className="border-[#1A1A1A]/10 my-2" />

              <div className="flex justify-between text-black text-xs font-black uppercase">
                <span>Grand Total</span>
                <span className="text-[14px]">₹{grandTotal.toLocaleString()}</span>
              </div>
            </div>

            <button
              id="cart-checkout-btn"
              onClick={() => {
                onClose();
                onOpenCheckout();
              }}
              className="w-full py-4 bg-[#1A1A1A] text-white border border-[#1A1A1A] hover:bg-[#C4A484] hover:text-black transition duration-200 font-mono text-[10px] uppercase tracking-[0.2em] font-bold rounded-none flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>INJECT CHECKOUT DRAFT</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
