/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Sparkles, RefreshCw, Send } from "lucide-react";

export default function AIStylistSection() {
  const [occasion, setOccasion] = useState("evening");
  const [season, setSeason] = useState("Autumn");
  const [colorPreference, setColorPreference] = useState("Minimalist Earth Tones");
  const [temperature, setTemperature] = useState("Mild (16°C)");
  const [additional, setAdditional] = useState("");
  const [loading, setLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<string | null>(null);
  const [loadingPhase, setLoadingPhase] = useState("");

  const phases = [
    "Analyzing visual contrast ratios...",
    "Curating premium fabric textures & weights...",
    "Styling silhouettes according to proportional balance...",
    "Polishing day-to-night transitional accents...",
    "Formulating bespoke capsule recipe..."
  ];

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setRecommendation(null);
    
    // Rotate loading phases for high premium design look
    let phaseIndex = 0;
    setLoadingPhase(phases[0]);
    const timer = setInterval(() => {
      phaseIndex = (phaseIndex + 1) % phases.length;
      setLoadingPhase(phases[phaseIndex]);
    }, 1800);

    try {
      const res = await fetch("/api/stylist/suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          occasion,
          season,
          colorPreference,
          temperature,
          additionalPrompt: additional
        })
      });
      clearInterval(timer);
      if (res.ok) {
        const data = await res.json();
        setRecommendation(data.recommendation);
      } else {
        setRecommendation("An error occurred during formulation. Please try again.");
      }
    } catch (err) {
      clearInterval(timer);
      setRecommendation("Connection timed out. Using mock stylish recommendations.");
    }
    setLoading(false);
  };

  return (
    <div id="ai-stylist-view" className="max-w-5xl mx-auto px-4 py-8">
      
      {/* Intro Editorial Banner */}
      <div className="text-center max-w-2xl mx-auto mb-16 border-b border-[#1A1A1A]/10 pb-12">
        <span className="font-serif text-sm italic text-[#C4A484] tracking-widest uppercase block mb-2 font-bold">Bespoke Guidance Engine</span>
        <h1 className="font-serif text-4xl sm:text-5xl text-[#1A1A1A] tracking-tighter font-black leading-none uppercase">
          AI Couturier
        </h1>
        <p className="font-mono text-[9px] text-[#1A1A1A]/60 uppercase tracking-[0.3em] mt-3 font-bold">
          Powered by Gemini AI • Deep Fashion Synthesis
        </p>
        <p className="font-sans text-xs text-stone-600 mt-5 leading-relaxed max-w-lg mx-auto">
          Input your occasion context, aesthetic moods, and temperature settings. Aura Stylist compiles a tailored fashion recipe, analyzing drape play, color theory, and transitions instantly.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Style Parameters Panel - Form */}
        <div className="lg:col-span-5 bg-white border border-[#1A1A1A] p-6 rounded-none shadow-[4px_4px_0px_0px_rgba(26,26,26,1)] space-y-6">
          <div className="flex items-center gap-2 border-b border-[#1A1A1A] pb-3 mb-1">
            <Sparkles className="w-4 h-4 text-[#C4A484]" />
            <h3 className="font-mono text-xs uppercase tracking-wider font-bold text-[#1A1A1A]">Design Inputs</h3>
          </div>

          <form onSubmit={handleGenerate} className="space-y-5">
            <div>
              <label className="block text-[9px] font-mono uppercase tracking-[0.2em] font-bold text-stone-400 mb-2">Target Occasion</label>
              <select
                value={occasion}
                onChange={(e) => setOccasion(e.target.value)}
                className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none transition cursor-pointer"
              >
                <option value="casual">Casual Streetwear Walk</option>
                <option value="formal">High-Stakes Corporate Meet</option>
                <option value="evening">Luxurious Evening Gala</option>
                <option value="resort">Sunny Coastline Getaway</option>
                <option value="gallery">Avant-Garde Art Exhibition</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase tracking-[0.2em] font-bold text-stone-400 mb-2">Seasonal Accent</label>
              <select
                value={season}
                onChange={(e) => setSeason(e.target.value)}
                className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none transition cursor-pointer"
              >
                <option value="Spring">Spring Bloom (Flowy Linens)</option>
                <option value="Summer">Summer Riviera (Breezy Silks)</option>
                <option value="Autumn">Autumn Layering (Rich Wool-Knits)</option>
                <option value="Winter">Winter Blizzard (Thick Outerwear)</option>
                <option value="All-Season">Timeless Capsule (Year-Round)</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase tracking-[0.2em] font-bold text-stone-400 mb-2">Color Palette Preference</label>
              <input
                type="text"
                value={colorPreference}
                onChange={(e) => setColorPreference(e.target.value)}
                placeholder="E.g. Emerald & Charcoal, Neutrals"
                className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none transition"
              />
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase tracking-[0.2em] font-bold text-stone-400 mb-2">Ideal Climate Temperature</label>
              <input
                type="text"
                value={temperature}
                onChange={(e) => setTemperature(e.target.value)}
                placeholder="E.g. 18°C Mild Breezy"
                className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none transition"
              />
            </div>

            <div>
              <label className="block text-[9px] font-mono uppercase tracking-[0.2em] font-bold text-stone-400 mb-2 flex justify-between">
                <span>Specific Aesthetic Detail</span>
                <span className="text-stone-300 font-bold lowercase italic">optional</span>
              </label>
              <textarea
                value={additional}
                onChange={(e) => setAdditional(e.target.value)}
                rows={3}
                placeholder="E.g. Must feature Chelsea suede boots and layered cashmere coats, double breasted."
                className="w-full bg-white border border-[#1A1A1A] rounded-none px-3 py-2.5 text-xs font-mono font-bold uppercase focus:bg-[#F9F8F6] focus:outline-none transition resize-none"
              />
            </div>

            <button
              id="stylist-generate-btn"
              type="submit"
              disabled={loading}
              className={`w-full py-4 bg-[#1A1A1A] text-white hover:bg-[#C4A484] hover:text-black border border-[#1A1A1A] transition duration-200 font-mono text-[10px] uppercase tracking-[0.2em] font-bold rounded-none flex items-center justify-center gap-2 cursor-pointer ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>SYNTHESIZING...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>COMPILE LOOK RECIPE</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Output Panel / Look Recipe Render with Golden Accent Sharp Shadows */}
        <div className="lg:col-span-7 bg-[#1A1A1A] text-[#F9F8F6] border border-[#1A1A1A] rounded-none min-h-[460px] shadow-[6px_6px_0px_0px_rgba(196,164,132,1)] overflow-hidden flex flex-col p-6 sm:p-8 relative">
          
          {/* Subtle luxurious grid background design accent */}
          <div className="absolute inset-0 bg-[radial-gradient(#262626_1px,transparent_1px)] [background-size:16px_16px] opacity-25 pointer-events-none" />

          {loading ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6 z-10 py-16">
              <div className="w-16 h-16 rounded-none border border-dashed border-[#C4A484] flex items-center justify-center animate-spin">
                <Sparkles className="w-6 h-6 text-[#C4A484]" />
              </div>
              <div className="space-y-2">
                <p className="font-serif text-lg text-[#F9F8F6] italic">{loadingPhase}</p>
                <p className="font-mono text-[9px] tracking-[0.25em] text-[#C4A484] uppercase font-bold">Consulting Aura Labs Engine</p>
              </div>
            </div>
          ) : recommendation ? (
            <div className="z-10 flex-1 flex flex-col">
              <div className="flex justify-between items-center border-b border-white/10 pb-4 mb-6">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-none bg-emerald-400 animate-pulse" />
                  <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#C4A484] font-bold">Bespoke Look Recipe</span>
                </div>
                <button
                  onClick={() => setRecommendation(null)}
                  className="px-2 py-1 border border-white/20 text-[#F9F8F6]/60 hover:text-white hover:border-white transition-all text-[9px] flex items-center gap-1 font-mono uppercase tracking-wider cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              </div>

              {/* Styled Advice */}
              <div className="flex-1 max-h-[500px] overflow-y-auto pr-2">
                <ElegantMarkdown text={recommendation} />
              </div>
            </div>
          ) : (
            <div className="z-10 flex-1 flex flex-col items-center justify-center text-center space-y-5 max-w-md mx-auto py-16">
              <div className="w-14 h-14 border border-white/10 flex items-center justify-center text-[#F9F8F6]/40 rounded-none bg-white/5">
                <Send className="w-5 h-5" />
              </div>
              <div className="space-y-2">
                <h4 className="font-serif text-xl font-bold text-[#F9F8F6] uppercase tracking-wide">Aura Stylist Ready</h4>
                <p className="font-sans text-xs text-[#F9F8F6]/60 leading-relaxed">
                  Design rules are configured and server is ready to compile. Press **Compile Look Recipe** on the left panel to trigger Gemini smart analysis.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}

// Elegant HTML renderer for beautiful high-fashion markdown display inside the neutral panel
function ElegantMarkdown({ text }: { text: string }) {
  if (!text) return null;
  const lines = text.split('\n');
  return (
    <div className="space-y-5 text-stone-300 leading-relaxed font-sans text-xs">
      {lines.map((line, i) => {
        const trimmed = line.trim();
        
        // Headers parsing
        if (trimmed.startsWith('###')) {
          const parsed = trimmed.replace(/^###\s*/, '').replace(/\*\*/g, '');
          return (
            <h3 key={i} className="text-[11px] font-mono font-bold uppercase tracking-[0.2em] text-[#C4A484] mt-6 pb-2.5 border-b border-white/10">
              {parsed}
            </h3>
          );
        }
        if (trimmed.startsWith('##')) {
          const parsed = trimmed.replace(/^##\s*/, '').replace(/\*\*/g, '');
          return (
            <h2 key={i} className="text-sm font-serif font-black text-[#F9F8F6] mt-8 mb-3 border-l-2 border-[#C4A484] pl-3 uppercase">
              {parsed}
            </h2>
          );
        }
        if (trimmed.startsWith('1.') || trimmed.startsWith('2.') || trimmed.startsWith('3.') || trimmed.startsWith('4.')) {
          // Ordered elements
          const content = trimmed.replace(/^\d+\.\s*/, '');
          const parts = content.split('**');
          return (
            <div key={i} className="flex items-start gap-3 pl-1 mt-3">
              <span className="font-serif text-[#C4A484] text-xs font-bold italic shrink-0">{trimmed.match(/^\d+/)?.toString()}.</span>
              <p className="text-stone-300 text-xs">
                {parts.map((p, idx) => idx % 2 === 1 ? <strong key={idx} className="font-bold text-white">{p}</strong> : p)}
              </p>
            </div>
          );
        }
        
        // Bullet elements
        if (trimmed.startsWith('*') || trimmed.startsWith('-')) {
          const content = trimmed.replace(/^[\*\-]\s*/, '');
          const parts = content.split('**');
          return (
            <div key={i} className="flex items-start gap-2.5 my-2.5 pl-3">
              <span className="w-1.5 h-1.5 bg-[#C4A484] mt-1.5 shrink-0" />
              <p className="text-stone-300 text-xs leading-relaxed">
                {parts.map((p, idx) => idx % 2 === 1 ? <strong key={idx} className="font-bold text-white tracking-widest text-[10px] uppercase">{p}</strong> : p)}
              </p>
            </div>
          );
        }
        
        if (trimmed === '---') {
          return <hr key={i} className="my-5 border-white/10" />;
        }
        if (trimmed === '') {
          return null;
        }

        // Standard with internal bold parsing
        const parts = trimmed.split('**');
        return (
          <p key={i} className="text-stone-300 leading-relaxed text-xs my-1.5 text-justify">
            {parts.map((p, idx) => idx % 2 === 1 ? <strong key={idx} className="font-bold text-white">{p}</strong> : p)}
          </p>
        );
      })}
    </div>
  );
}
