/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { useApp } from "./AppContext";
import { X, Mail, Lock, User, Eye, EyeOff, ShieldCheck } from "lucide-react";

export default function AuthModal() {
  const { showAuthModal, setShowAuthModal, loginUser, registerUser } = useApp();
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [localErr, setLocalErr] = useState<string | null>(null);

  if (!showAuthModal) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalErr(null);

    if (!email || !password || (isRegister && !name)) {
      setLocalErr("Please complete all fields.");
      return;
    }

    if (isRegister) {
      const ok = await registerUser(name, email, password);
      if (ok) {
        setShowAuthModal(false);
        resetForm();
      }
    } else {
      const ok = await loginUser(email, password);
      if (ok) {
        setShowAuthModal(false);
        resetForm();
      }
    }
  };

  const resetForm = () => {
    setEmail("");
    setName("");
    setPassword("");
    setLocalErr(null);
  };

  // Instructor demo login helper
  const handleDemoLogin = async (role: 'kartheek' | 'apoorva') => {
    if (role === 'kartheek') {
      setEmail("kartheek@style.com");
      setPassword("123");
      const ok = await loginUser("kartheek@style.com", "123");
      if (ok) setShowAuthModal(false);
    } else {
      setEmail("apoorva@style.com");
      setPassword("123");
      const ok = await loginUser("apoorva@style.com", "123");
      if (ok) setShowAuthModal(false);
    }
  };

  return (
    <div id="auth-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center bg-[#1A1A1A]/60 backdrop-blur-sm p-4">
      <div className="bg-[#F9F8F6] rounded-none w-full max-w-md border-2 border-[#1A1A1A] overflow-hidden flex flex-col shadow-[8px_8px_0px_0px_rgba(26,26,26,1)]">
        
        {/* Header Block with Luxe Pattern */}
        <div className="bg-[#1A1A1A] text-[#F9F8F6] p-6 relative">
          <button
            id="auth-close-btn"
            onClick={() => setShowAuthModal(false)}
            className="absolute top-4 right-4 p-1 border border-white/20 hover:border-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
          
          <span className="font-mono text-[9px] tracking-[0.25em] text-[#C4A484] block mb-1 font-bold">WELCOME TO THE STUDIO</span>
          <h2 className="font-serif text-2xl tracking-tight font-black uppercase text-white">
            {isRegister ? "Join Aura" : "Personal Atelier"}
          </h2>
          <p className="font-sans text-[11px] text-stone-300 mt-1 pb-1">
            {isRegister ? "Begin looks mapping and save tailored suggestions." : "Explore curated trends, checkout saved garments and prompt stylist AI."}
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 flex-1">
          {localErr && (
            <div className="bg-red-50 text-red-700 text-xs px-3 py-2.5 rounded-none mb-4 font-mono font-bold flex items-center border border-red-200">
              {localErr}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {isRegister && (
              <div>
                <label className="block text-[9px] font-mono font-bold text-stone-400 uppercase tracking-wider mb-1.5">Full Name</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400"><User className="w-3.5 h-3.5" /></span>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="E.g. Podduturi Kartheek"
                    className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#1A1A1A] rounded-none font-mono text-xs uppercase font-bold focus:outline-none focus:bg-[#F9F8F6]"
                    required
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-[9px] font-mono font-bold text-stone-400 uppercase tracking-wider mb-1.5">Email Address</label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400"><Mail className="w-3.5 h-3.5" /></span>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#1A1A1A] rounded-none font-mono text-xs uppercase font-bold focus:outline-none focus:bg-[#F9F8F6]"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-[9px] font-mono font-bold text-stone-400 uppercase tracking-wider mb-1.5 flex justify-between">
                <span>Password</span>
                <span className="text-[10px] text-stone-400 lowercase italic">demo key &quot;123&quot;</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400"><Lock className="w-3.5 h-3.5" /></span>
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-10 py-2.5 bg-white border border-[#1A1A1A] rounded-none font-mono text-xs focus:outline-none"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-black transition"
                >
                  {showPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <button
              id="auth-submit-btn"
              type="submit"
              className="w-full mt-2 bg-[#1A1A1A] text-white py-3.5 border border-[#1A1A1A] rounded-none font-mono text-[10px] uppercase tracking-widest font-bold hover:bg-[#C4A484] hover:text-black transition duration-200 cursor-pointer shadow-[3px_3px_0px_0px_rgba(26,26,26,1)]"
            >
              {isRegister ? "REGISTER ACCOUNT" : "AUTHENTICATE CURRENT ACCOUNT"}
            </button>
          </form>

          {/* Toggle Register/Login Link */}
          <div className="mt-5 text-center leading-none">
            <button
              onClick={() => setIsRegister(!isRegister)}
              className="font-mono text-[10px] uppercase text-[#C4A484] hover:text-[#1A1A1A] font-medium transition cursor-pointer"
            >
              {isRegister ? "Already matching? Access Personal Login" : "New member? Join lookbook builders"}
            </button>
          </div>

          {/* Demo Shortcut Panel */}
          <div className="mt-6 border border-[#1A1A1A] p-4 rounded-none bg-white">
            <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold text-stone-800 uppercase tracking-wider mb-3">
              <ShieldCheck className="w-3.5 h-3.5 text-[#C4A484]" />
              <span>Project Review Quick Access (Demo Roles)</span>
            </div>
            <p className="font-sans text-[11px] text-stone-500 mb-4 leading-relaxed">
              Login immediately using pre-configured student test accounts. Satisfies admin management & standard client features simultaneously:
            </p>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => handleDemoLogin('kartheek')}
                className="py-2.5 px-2 border border-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white text-center transition flex flex-col items-center bg-white cursor-pointer rounded-none"
              >
                <span className="font-mono text-xs font-bold text-[#1A1A1A] uppercase tracking-wide">KARTHEEK</span>
                <span className="font-mono text-[8px] text-stone-400 uppercase tracking-wider font-bold mt-1">Admin Panel / DB</span>
              </button>
              <button
                type="button"
                onClick={() => handleDemoLogin('apoorva')}
                className="py-2.5 px-2 border border-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white text-center transition flex flex-col items-center bg-white cursor-pointer rounded-none"
              >
                <span className="font-mono text-xs font-bold text-[#1A1A1A] uppercase tracking-wide">APOORVA</span>
                <span className="font-mono text-[8px] text-stone-400 uppercase tracking-wider font-bold mt-1">Cart & Checkout</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
