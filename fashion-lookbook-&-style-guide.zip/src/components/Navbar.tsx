/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { useApp } from "./AppContext";
import { ShoppingBag, Heart, User, Sparkles, LogOut, Lock, Truck, Sun, Moon } from "lucide-react";

export default function Navbar({
  onTabChange,
  activeTab,
  onOpenCart,
  onOpenWishlist
}: {
  onTabChange: (tab: 'lookbook' | 'catalog' | 'stylist' | 'tracker' | 'admin') => void;
  activeTab: string;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
}) {
  const { currentUser, logoutUser, setShowAuthModal, cart, wishlist, isDarkMode, toggleDarkMode } = useApp();

  const cartItemsCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <header id="app-navbar" className="sticky top-0 z-40 bg-white dark:bg-[#121211] border-b border-[#1A1A1A] dark:border-[#F5F4F0]/15 text-[#1A1A1A] dark:text-[#F5F4F0] transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Logo Brand Accent - Geometric Italic Serif */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onTabChange('lookbook')}>
            <div className="flex flex-col sm:flex-row sm:items-baseline sm:gap-2">
              <span className="font-serif text-3xl font-black italic tracking-tighter text-[#1A1A1A] dark:text-[#F5F4F0]">AURA.</span>
              <span className="font-mono text-[9px] tracking-[0.3em] text-[#C4A484] dark:text-[#D4AF37] font-bold uppercase">COUTURA ATELIER</span>
            </div>
          </div>

          {/* Core Navigation Links */}
          <nav className="hidden md:flex items-center space-x-12 font-sans text-xs tracking-[0.3em] font-bold uppercase text-[#1A1A1A]/40 dark:text-stone-500">
            <button
              id="nav-lookbook"
              onClick={() => onTabChange('lookbook')}
              className={`hover:text-[#1A1A1A] dark:hover:text-[#F5F4F0] transition-colors duration-200 py-2 relative cursor-pointer ${activeTab === 'lookbook' ? 'text-[#1A1A1A] dark:text-[#F5F4F0] border-b-2 border-[#1A1A1A] dark:border-[#F5F4F0]' : ''}`}
            >
              Lookbook
            </button>
            <button
              id="nav-catalog"
              onClick={() => onTabChange('catalog')}
              className={`hover:text-[#1A1A1A] dark:hover:text-[#F5F4F0] transition-colors duration-200 py-2 relative cursor-pointer ${activeTab === 'catalog' ? 'text-[#1A1A1A] dark:text-[#F5F4F0] border-b-2 border-[#1A1A1A] dark:border-[#F5F4F0]' : ''}`}
            >
              Collections
            </button>
            <button
              id="nav-stylist"
              onClick={() => onTabChange('stylist')}
              className={`hover:text-[#C4A484] focus:text-[#C4A484] transition-colors duration-200 py-2 relative flex items-center gap-1.5 cursor-pointer font-bold ${activeTab === 'stylist' ? 'text-[#C4A484] border-b-2 border-[#C4A484]' : 'text-[#C4A484]/70 dark:text-[#C4A484]'}`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              AI Stylist
            </button>
            <button
              id="nav-tracker"
              onClick={() => onTabChange('tracker')}
              className={`hover:text-[#1A1A1A] dark:hover:text-[#F5F4F0] transition-colors duration-200 py-2 relative flex items-center gap-1.5 cursor-pointer font-bold ${activeTab === 'tracker' ? 'text-[#1A1A1A] dark:text-[#F5F4F0] border-b-2 border-[#1A1A1A] dark:border-[#F5F4F0]' : 'text-[#1A1A1A]/40'}`}
            >
              <Truck className="w-3.5 h-3.5" />
              Track Orders
            </button>
            {currentUser?.role === "admin" && (
              <button
                id="nav-admin"
                onClick={() => onTabChange('admin')}
                className={`hover:text-[#1A1A1A] dark:hover:text-[#F5F4F0] transition-colors duration-200 py-2 relative flex items-center gap-1 cursor-pointer font-bold ${activeTab === 'admin' ? 'text-[#1A1A1A] dark:text-[#F5F4F0] border-b-2 border-[#1A1A1A] dark:border-[#F5F4F0]' : ''}`}
              >
                <Lock className="w-3 h-3" />
                Admin
              </button>
            )}
          </nav>

          {/* Quick Session & Action Controls */}
          <div className="flex items-center space-x-4">
            
            {/* Dark & Light Theme Toggle Switch */}
            <button
              id="theme-toggle-btn"
              onClick={toggleDarkMode}
              className="p-2.5 text-[#1A1A1A] dark:text-[#F5F4F0] hover:bg-[#F9F8F6] dark:hover:bg-[#1E1E1D] transition-colors border border-[#1A1A1A]/10 dark:border-[#F5F4F0]/15 bg-white dark:bg-[#1C1C1B] cursor-pointer"
              title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400 stroke-[1.8]" /> : <Moon className="w-4 h-4 text-indigo-500 stroke-[1.8]" />}
            </button>

            {/* Wishlist Icon */}
            <button 
              id="nav-btn-wishlist"
              onClick={onOpenWishlist}
              className="relative p-2.5 text-[#1A1A1A] dark:text-[#F5F4F0] hover:bg-[#F9F8F6] dark:hover:bg-[#1E1E1D] transition-colors border border-[#1A1A1A]/10 dark:border-[#F5F4F0]/15 bg-white dark:bg-[#1C1C1B] cursor-pointer"
              title="Saved Styles"
            >
              <Heart className="w-4 h-4 stroke-[1.8]" />
              {wishlist.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-[#C4A484] text-white font-mono text-[8px] px-1 font-bold border border-[#1A1A1A] dark:border-[#F5F4F0]">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Shopping Bag Icon */}
            <button
              id="nav-btn-cart"
              onClick={onOpenCart}
              className="relative p-2.5 text-[#1A1A1A] dark:text-[#F5F4F0] hover:bg-[#1A1A1A] hover:text-white dark:hover:bg-[#F5F4F0] dark:hover:text-black transition-colors border border-[#1A1A1A] dark:border-[#F5F4F0]/20 bg-white dark:bg-[#1C1C1B] flex items-center space-x-1.5 cursor-pointer"
              title="Bag"
            >
              <ShoppingBag className="w-4 h-4 stroke-[1.8]" />
              <span className="text-[10px] font-bold uppercase tracking-widest hidden sm:inline">Bag</span>
              {cartItemsCount > 0 && (
                <span className="bg-[#1A1A1A] dark:bg-[#F5F4F0] text-white dark:text-black text-[8px] px-1 font-mono font-bold">
                  {cartItemsCount}
                </span>
              )}
            </button>

            {/* User Session Profile & Actions */}
            <div className="h-6 w-px bg-gray-200 dark:bg-stone-800 hidden sm:block" />

            {currentUser ? (
              <div className="flex items-center space-x-3">
                <div className="hidden lg:flex flex-col items-end text-end leading-none">
                  <span className="font-sans text-[11px] font-bold text-[#1A1A1A] dark:text-[#F5F4F0]">{currentUser.name}</span>
                  <span className="font-mono text-[8px] font-bold text-[#C4A484] dark:text-[#D4AF37] uppercase tracking-widest mt-0.5">
                    {currentUser.role}
                  </span>
                </div>
                <div className="w-9 h-9 border border-[#1A1A1A] dark:border-[#F5F4F0]/30 bg-white dark:bg-[#1E1E1D] flex items-center justify-center font-serif text-sm italic font-bold text-[#1A1A1A] dark:text-[#F5F4F0]">
                  {currentUser.name.charAt(0)}
                </div>
                <button
                  id="nav-btn-logout"
                  onClick={logoutUser}
                  className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors duration-200 hover:bg-neutral-50 dark:hover:bg-stone-900"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                id="nav-btn-login"
                onClick={() => setShowAuthModal(true)}
                className="flex items-center space-x-1.5 py-2 px-4 border border-[#1A1A1A] dark:border-[#F5F4F0] bg-[#1A1A1A] dark:bg-[#F5F4F0] text-white dark:text-black hover:bg-white dark:hover:bg-[#1A1A1A] hover:text-[#1A1A1A] dark:hover:text-[#F5F4F0] text-[10px] tracking-wider uppercase font-bold transition duration-200 cursor-pointer"
              >
                <User className="w-3.5 h-3.5" />
                <span>Join</span>
              </button>
            )}

          </div>
        </div>
      </div>
    </header>
  );
}
